import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
const root = fileURLToPath(new URL('.', import.meta.url));
const pack = resolve(root, '..');
const engine = resolve(process.env.CLINICALCRAFT_DIR || join(pack, '..', 'ClinicalCraft'));
export default {
  root, base: './',
  resolve: { alias: [{ find: /^three$/, replacement: join(engine, 'node_modules/three/build/three.module.js') },
    { find: /^three\//, replacement: join(engine, 'node_modules/three/') }] },
  plugins: [{ name: 'surgerycraft-hospital-document', resolveId(id) { if (id === 'virtual:surgerycraft/hospital') return '\0surgerycraft-hospital'; },
    load(id) { if (id === '\0surgerycraft-hospital') return 'export default ' + JSON.stringify(readFileSync(join(pack, 'output/delivery-1654623/SurgeryCraft_病例126_离线演示.html'), 'utf8')); } }],
  server: { host: '127.0.0.1', port: 8866, fs: { allow: [pack, engine] } },
  build: { target: 'es2022', outDir: join(pack, 'output/surgical-view-build'), emptyOutDir: true,
    assetsInlineLimit: 50_000_000, chunkSizeWarningLimit: 20000, cssCodeSplit: false,
    rollupOptions: { output: { inlineDynamicImports: true } } },
};
