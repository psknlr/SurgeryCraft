/** Small deterministic teaching-animation state, independent of clinical assessment. */
export const STAGE_COUNT = 8;
export function initialState() { return { time: 0, playing: false, reviewedStructures: false, understoodBoundary: false, laterality: 'case' }; }
export function checked(state) { return state.reviewedStructures && state.understoodBoundary; }
export function seek(state, time) {
  const bounded = Math.min(STAGE_COUNT - 1, Math.max(0, Number.isFinite(time) ? time : 0));
  const blocked = bounded > 3 && !checked(state);
  return { state: { ...state, time: blocked ? 3 : bounded, playing: blocked ? false : state.playing }, blocked };
}
export function tick(state, dt) {
  if (!state.playing) return { state, blocked: false };
  const result = seek(state, state.time + Math.min(.1, Math.max(0, dt)) / 4);
  if (result.state.time >= STAGE_COUNT - 1) result.state.playing = false;
  return result;
}
