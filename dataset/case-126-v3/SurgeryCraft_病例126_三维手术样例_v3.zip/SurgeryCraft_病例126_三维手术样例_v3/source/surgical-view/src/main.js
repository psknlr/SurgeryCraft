import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import modelUrl from '../../content/assets/models/cmcr-1654623-mirror-abdomen.glb?url';
import hospitalHtml from 'virtual:surgerycraft/hospital';
import { structures, stages, labels } from './content.js';
import { initialState, seek, tick, checked } from './state.mjs';
import './style.css';

let language = 'zh';
let state = initialState();
let selected = 'gallbladder';
let baseOpacity = 1;
let liverOverride = false;
let showLabels = true;
let isolated = false;
let scope = false;
let loaded = false;
let model;
let hospitalLoaded = false;
let lastStage = -1;
let cameraTween = null;
const hiddenStructures = new Set();
const history = [];
const byId = new Map(structures.map(s => [s[0], s]));
const tr = key => labels[key][language];
const tx = value => value[language];
const nameOf = id => byId.get(id)?.[language === 'zh' ? 2 : 3] || id;
const smooth = value => { const x = THREE.MathUtils.clamp(value, 0, 1); return x*x*(3-2*x); };
const record = (type, detail = {}) => history.push({ sequence: history.length + 1, type, time: Number(state.time.toFixed(3)), laterality: state.laterality, ...detail });
const root = document.querySelector('#app');
root.innerHTML = `
<header class="topbar"><div class="brand">SURGERY<span>CRAFT</span></div><div class="case-pill" data-i18n="case"></div>
 <nav><button id="anatomy-tab" class="active" data-i18n="anatomy"></button><button id="hospital-tab" data-i18n="hospital"></button><button id="language">EN</button></nav></header>
<main class="shell">
 <aside class="left"><p class="eyebrow">ANATOMY EXPLORER</p><h2 data-i18n="library"></h2><input id="search" class="search" type="search"><div id="structure-list"></div><p class="footnote" data-i18n="controls"></p></aside>
 <section class="workspace"><div class="canvas-wrap" id="canvas-wrap"><canvas id="operative-canvas" aria-label="Interactive 3D operative anatomy"></canvas>
  <div class="view-head"><h1 data-i18n="title"></h1><p id="model-kind"></p></div>
  <div class="view-tools"><button id="laterality"></button><button id="scope"></button><button id="reset" data-i18n="reset"></button></div>
  <div class="model-label" id="picked-label"></div><div class="scope-frame"></div>
  <div class="mobile-card" id="mobile-instruction"></div><div class="status" id="status" role="status"></div>
  <div class="axes"><span class="axis-tag" data-i18n="patientRight"></span><span class="axis-tag" data-i18n="patientLeft"></span></div>
 </div><div class="timeline"><div class="timeline-top"><button class="play" id="play"></button><button id="previous" aria-label="Previous stage">‹</button><strong id="stage-number"></strong><input class="time-range" id="timeline" type="range" min="0" max="7" step="0.01"><button id="next" aria-label="Next stage">›</button></div><div class="step-list" id="stage-list"></div></div></section>
 <aside class="right" id="right"><p class="eyebrow">CASE 126 / OPERATIVE FIELD</p><h2 data-i18n="details"></h2>
  <section class="card" id="structure-card"></section>
 <section class="card controls-card"><label class="slider-row"><span data-i18n="opacity"></span><input id="opacity" type="range" min="0.05" max="1" step="0.01" value="1"></label><div class="button-row"><button id="focus" data-i18n="isolate"></button><button id="all" data-i18n="all"></button></div><label class="slider-row"><span><input type="checkbox" id="labels" checked> <span data-i18n="labels"></span></span></label></section>
  <section class="card stage-card" id="stage-card"></section>
  <section class="card evidence-card"><h3 data-i18n="evidence"></h3><p data-i18n="evidenceBody"></p></section>
  <div class="boundary" data-i18n="boundary"></div><button id="export" data-i18n="export"></button>
  <p class="footnote"><a href="https://dbarchive.biosciencedbc.jp/en/bodyparts3d/lic.html" target="_blank" rel="noreferrer">BodyParts3D / DBCLS · CC BY 4.0</a><br><span data-i18n="refer"></span></p>
 </aside>
</main><section class="hospital-area"><div class="hospital-note" id="hospital-note"></div><iframe id="hospital-frame" title="Hospital case workflow"></iframe></section>`;

const $ = id => document.getElementById(id);
const canvas = $('operative-canvas');
const container = $('canvas-wrap');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#111c20');
scene.fog = new THREE.Fog('#111c20', 10, 20);
const camera = new THREE.PerspectiveCamera(41, 1, .01, 60);
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
const controls = new OrbitControls(camera, canvas);
controls.target.set(.15, 1.2, 0);
controls.enableDamping = true;
controls.minDistance = .5;
controls.maxDistance = 11;
controls.addEventListener('start', () => { cameraTween = null; });
const defaultCamera = () => { camera.position.set(-.6, .55, 6.5); controls.target.set(.25, 1.40, 0); controls.update(); };
defaultCamera();
scene.add(new THREE.HemisphereLight(0xe6dddd, 0x2d1817, .65));
for (const [color, power, position] of [[0xffe7d5, 2.5, [-3,5,5]], [0xd3e4f1, .75, [4,2,3]], [0xffddc5, 1.5, [1,4,-3]]]) {
  const light = new THREE.DirectionalLight(color, power); light.position.set(...position); scene.add(light);
}
const pickables = [];
const meshes = [];
const named = new Map();
const bones = {};
const selectionBox = new THREE.Box3();
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
let pointerStart;
let statusUntil = 0;

function status(message, duration = 0) { $('status').textContent = message; statusUntil = duration ? performance.now()+duration : 0; }
function stageIndex() { return Math.min(7, Math.floor(state.time + 1e-6)); }
function updateStructureList() {
  const query = $('search').value.trim().toLowerCase();
  $('structure-list').innerHTML = '';
  for (const entry of structures.filter(s => !query || [s[2],s[3]].join(' ').toLowerCase().includes(query))) {
    const [id,color] = entry;
    const row = document.createElement('div'); row.className = 'structure';
    const button = document.createElement('button'); button.type = 'button'; button.dataset.structure = id;
    button.classList.toggle('selected', selected === id);
    const swatch = document.createElement('span'); swatch.className = 'swatch'; swatch.style.setProperty('--color',color);
    button.append(swatch, document.createTextNode(nameOf(id))); button.onclick = () => select(id);
    const visible = document.createElement('input'); visible.type = 'checkbox'; visible.checked = !hiddenStructures.has(id);
    visible.setAttribute('aria-label', tr('visible')+' '+nameOf(id));
    visible.onchange = () => { visible.checked ? hiddenStructures.delete(id) : hiddenStructures.add(id); record('visibility',{ structure: id, visible: visible.checked }); updateVisuals(); };
    row.append(button, visible); $('structure-list').append(row);
  }
}
function updateStructureCard() {
  const entry = byId.get(selected);
  $('structure-card').innerHTML = `<span class="tag ${entry[6] === 'schematic' ? 'schematic' : ''}">${tr(entry[6] === 'case' ? 'source' : 'schematic')}</span><div class="large">${nameOf(selected)}</div><div class="english">${entry[3]}</div><p>${entry[language==='zh'?4:5]}</p>`;
}
function updateStageCard() {
  const i = stageIndex();
  $('stage-card').innerHTML = `<p class="eyebrow">STEP ${String(i+1).padStart(2,'0')}</p><h3>${tx(stages[i].title)}</h3><p>${tx(stages[i].body)}</p>`;
  if (i === 3) {
    const checklist = document.createElement('div'); checklist.className = 'checklist';
    for (const [id,key,field] of [['review-structures','check1','reviewedStructures'],['review-boundary','check2','understoodBoundary']]) {
      const label = document.createElement('label'); const input = document.createElement('input'); input.type='checkbox'; input.id=id; input.checked=state[field];
    input.onchange = () => { state = { ...state, [field]: input.checked }; record('learning-check',{field,checked:input.checked}); updateTimeline(); $('right').classList.toggle('gated',!checked(state)); };
      label.append(input, document.createTextNode(tr(key))); checklist.append(label);
    }
    $('stage-card').append(checklist);
    requestAnimationFrame(()=>$('stage-card').scrollIntoView({block:'nearest',behavior:'smooth'}));
  }
  $('right').classList.toggle('gated',i===3&&!checked(state));
  $('mobile-instruction').textContent = tx(stages[i].body);
}
function updateTimeline() {
  const i = stageIndex();
  $('timeline').value = String(state.time);
  $('stage-number').textContent = `${String(i+1).padStart(2,'0')} / 08`;
  $('play').textContent = tr(state.playing?'pause':'play');
  $('play').setAttribute('aria-pressed',String(state.playing));
  $('previous').disabled = i===0;
  $('next').disabled = i===7;
  root.dataset.stage = stages[i].id;
  root.dataset.laterality = state.laterality;
  root.dataset.reviewPassed = String(checked(state));
  for (const button of $('stage-list').children) {
    const n=Number(button.dataset.index);button.classList.toggle('current',n===i);button.classList.toggle('done',n<i);
  }
  if (i!==lastStage) { lastStage=i; updateStageCard(); }
}
function translate() {
  document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
  for (const element of document.querySelectorAll('[data-i18n]')) element.textContent=tr(element.dataset.i18n);
  $('search').placeholder=tr('search'); $('search').setAttribute('aria-label',tr('search'));
  $('timeline').setAttribute('aria-label', language==='zh'?'演示进度':'Demonstration progress');
  $('opacity').setAttribute('aria-label',tr('opacity'));
  $('laterality').textContent=tr(state.laterality==='case'?'mirror':'normal');
  $('scope').textContent=tr(scope?'overview':'scope'); $('language').textContent=language==='zh'?'EN':'中文';
  $('model-kind').textContent=state.laterality==='case' ? (language==='zh'?'BodyParts3D © DBCLS · CC BY 4.0 · 镜像适配':'BodyParts3D © DBCLS · CC BY 4.0 · mirrored adaptation') : tr('compareNote');
  $('hospital-note').textContent=language==='zh'?'医院内搜索“84”，选择病例和 IMPF 外科医院。':'In the hospital library search “84” and choose IMPF Surgery Hospital.';
  $('stage-list').innerHTML='';
  stages.forEach((s,i)=> { const button=document.createElement('button');button.dataset.index=i;button.innerHTML=`<span class="step-index">${String(i+1).padStart(2,'0')}</span>${tx(s.title)}`;button.onclick=()=>moveTo(i);$('stage-list').append(button); });
  updateStructureList();updateStructureCard();updateStageCard();updateTimeline();
}
function select(id) { selected=id;isolated=false;record('select',{structure:id});updateStructureList();updateStructureCard();updateVisuals(); }
function moveTo(time, log=true) {
  const previous=stageIndex(); const result=seek(state,time); state=result.state;
  if (result.blocked) status(tr('gate'),4500);
  if (log) record(result.blocked?'gate-refused':'seek',{requested:time});
  if (previous!==stageIndex()) {
    selected=stages[stageIndex()].focus; liverOverride=false; updateStructureList();updateStructureCard();
  }
  updateTimeline();updateVisuals();
}
function materialOpacity(mesh,value) {
  for (const material of Array.isArray(mesh.material)?mesh.material:[mesh.material]) {
    material.opacity=value; material.transparent=value<.995; material.depthWrite=value>=.995;
    if (material.emissive) { material.emissive.set(mesh.userData.structureId===selected?'#32150c':'#000000');material.emissiveIntensity=.10; }
  }
}
function updateVisuals() {
  if (!loaded) return;
  model.scale.x=state.laterality==='case'?1:-1;
  const t=state.time;
  const exposed=smooth(t);
  const separated=smooth(t-5);
  const extracted=smooth((t-6.2)/.8);
  named.get('Liver').position.set(0,.48*exposed,-.22*exposed);
  for (const mesh of meshes) {
    const id=mesh.userData.structureId;
    let opacity = id==='liver' ? baseOpacity : id==='context'?.10:1;
    mesh.visible=!hiddenStructures.has(id) && (!isolated || id===selected || id==='context');
    materialOpacity(mesh,opacity);
  }
  $('opacity').value=String(baseOpacity);
  named.get('LiverBed').visible=t>=5;
  const gb=bones.GallbladderAssembly;
  gb.position.set(.12*separated, .10*separated+.55*extracted, .52*separated+.65*extracted);
  gb.rotation.z=-.16*separated;
  gb.visible=extracted<.99&&!hiddenStructures.has('gallbladder');
  for(const name of ['CysticDuctDivision','CysticArteryDivision']) bones[name].visible=t<5;
  bones.Clips.visible=t>=4;
  bones.SpecimenBag.visible=t>=6.2&&extracted<.99;
  bones.SpecimenBag.position.copy(gb.position).add(new THREE.Vector3(.97,1.02,.54));
  bones.SpecimenBag.scale.setScalar(.85);
  // Specimen-side clips move with the detached organ; retained clips stay on the stumps.
  for(const name of ['Clip1','Clip3']) {
    const clip=named.get(name);
    clip.position.copy(clip.userData.restPosition).applyAxisAngle(new THREE.Vector3(0,0,1),gb.rotation.z).add(gb.position);
    clip.rotation.z=gb.rotation.z;
    clip.visible=extracted<.99;
  }
  for(const n of ['Grasper','ClipApplier','Dissector'])bones[n].visible=false;
  const placeInstrument=(name,tip,entry)=>{
    const object=bones[name];object.visible=true;
    const direction=tip.clone().sub(entry).normalize();
    object.position.copy(tip).addScaledVector(direction,-.08);
    object.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),direction);
  };
  if(t>=1&&t<7)placeInstrument('Grasper',new THREE.Vector3(1.02,1.05,.70).add(gb.position),new THREE.Vector3(-1.3,.0,3.5));
  if(t>=4&&t<5)placeInstrument('ClipApplier',new THREE.Vector3(.53,1.23,.58),new THREE.Vector3(1.7,.2,3.5));
  if(t>=5&&t<6.5)placeInstrument('Dissector',new THREE.Vector3(.53,1.51,.58),new THREE.Vector3(1.7,.2,3.5));
  const triangle=scene.getObjectByName('TeachingTriangle');
  triangle.visible=t>=2&&t<4;
  triangle.scale.x=state.laterality==='case'?1:-1;
  root.dataset.specimenRemoved=String(extracted>=.99);
  root.dataset.commonBileDuctPreserved=String(bones.CommonBileDuct.visible);
}

const triangleGeometry=new THREE.BufferGeometry();
triangleGeometry.setAttribute('position',new THREE.Float32BufferAttribute([.28,1.30,.58,.34,1.72,.58,.80,1.55,.58],3));
triangleGeometry.setIndex([0,1,2]);triangleGeometry.computeVertexNormals();
const triangle=new THREE.Mesh(triangleGeometry,new THREE.MeshBasicMaterial({color:0x64e3c4,transparent:true,opacity:.16,side:THREE.DoubleSide,depthWrite:false}));
triangle.name='TeachingTriangle';triangle.visible=false;scene.add(triangle);

new GLTFLoader().load(modelUrl,gltf=>{
  model=gltf.scene;scene.add(model);
  model.traverse(object=>{
    if(object.name)named.set(object.name,object);
    if(object.name==='Clip1'||object.name==='Clip3')object.userData.restPosition=object.position.clone();
    if(object.isMesh){
      if(!object.userData.structureId){let p=object.parent;while(p&&!object.userData.structureId){object.userData.structureId=p.userData.structureId;p=p.parent;}}
      object.material=Array.isArray(object.material)?object.material.map(m=>m.clone()):object.material.clone();
      meshes.push(object);
      if(byId.has(object.userData.structureId))pickables.push(object);
    }
  });
  for(const key of ['GallbladderAssembly','CommonBileDuct','CysticDuctDivision','CysticArteryDivision','Clips','SpecimenBag','Grasper','ClipApplier','Dissector']){
    bones[key]=named.get(key);if(!bones[key])throw new Error('Required anatomical mesh missing: '+key);
  }
  loaded=true;root.dataset.modelLoaded='true';root.dataset.meshCount=String(meshes.length);
  record('model-loaded',{meshes:meshes.length,geometry:'BodyParts3D reference surfaces + authored schematic ducts; not patient-derived'});
  status(tr('ready'));updateVisuals();
},undefined,error=>{status(String(error));root.dataset.modelLoaded='failed';console.error(error);});

function resize(){const w=container.clientWidth,h=container.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
new ResizeObserver(resize).observe(container);
canvas.addEventListener('pointerdown',event=>{pointerStart=[event.clientX,event.clientY];});
canvas.addEventListener('pointerup',event=>{
  if(!pointerStart||Math.hypot(event.clientX-pointerStart[0],event.clientY-pointerStart[1])>6)return;
  const rect=canvas.getBoundingClientRect();pointer.set((event.clientX-rect.left)/rect.width*2-1,-(event.clientY-rect.top)/rect.height*2+1);
  raycaster.setFromCamera(pointer,camera);
  const hit=raycaster.intersectObjects(pickables,false).find(intersection=>{let p=intersection.object;while(p){if(!p.visible)return false;p=p.parent;}return true;});
  if(hit)select(hit.object.userData.structureId);
});
$('search').oninput=updateStructureList;
$('language').onclick=()=>{language=language==='zh'?'en':'zh';translate();status(tr('ready'));};
$('timeline').oninput=event=>{state.playing=false;moveTo(Number(event.target.value));};
$('play').onclick=()=>{if(state.time>=7)moveTo(0);state.playing=!state.playing;record(state.playing?'play':'pause');updateTimeline();};
$('next').onclick=()=>{state.playing=false;moveTo(stageIndex()+1);};
$('previous').onclick=()=>{state.playing=false;moveTo(stageIndex()-1);};
$('opacity').oninput=event=>{baseOpacity=Number(event.target.value);liverOverride=true;updateVisuals();};
$('opacity').onchange=()=>record('opacity',{value:baseOpacity});
$('labels').onchange=event=>{showLabels=event.target.checked;record('labels',{visible:showLabels});};
$('laterality').onclick=()=>{state.laterality=state.laterality==='case'?'usual':'case';record('laterality');translate();updateVisuals();status(state.laterality==='case'?tr('ready'):tr('compareNote'),4500);};
$('focus').onclick=()=>{
  isolated=true;updateVisuals();model.updateMatrixWorld(true);
  const objects=meshes.filter(m=>m.userData.structureId===selected);
  selectionBox.makeEmpty();for(const object of objects)selectionBox.expandByObject(object);
  const centre=selectionBox.getCenter(new THREE.Vector3());const size=selectionBox.getSize(new THREE.Vector3()).length();
  cameraTween={position:centre.clone().add(new THREE.Vector3(0,.15,Math.max(.7,size*1.8))),target:centre};
  record('focus',{structure:selected});
};
$('all').onclick=()=>{isolated=false;hiddenStructures.clear();cameraTween=null;updateStructureList();defaultCamera();updateVisuals();record('show-all');};
$('scope').onclick=()=>{scope=!scope;container.classList.toggle('scope',scope);$('scope').textContent=tr(scope?'overview':'scope');cameraTween=scope?{position:new THREE.Vector3(1.55,.65,3.15),target:new THREE.Vector3(.78,1.20,.45)}:null;if(!scope)defaultCamera();record('camera',{scope});};
$('reset').onclick=()=>{state=initialState();selected='gallbladder';baseOpacity=1;liverOverride=false;isolated=false;scope=false;cameraTween=null;hiddenStructures.clear();lastStage=-1;container.classList.remove('scope');$('opacity').value='1';defaultCamera();translate();updateVisuals();record('reset');status(tr('ready'));};
$('export').onclick=()=>{
  record('export');
  const data={schema:'surgerycraft/visual-learning-trace@1',caseId:'cmcr-1654623',modelKind:'BodyParts3D adapted reference surfaces with authored schematic ducts, not patient-derived',notClinicalAssessment:true,modelVersion:'1.1',state,events:history};
  const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
  const anchor=document.createElement('a');anchor.href=url;anchor.download='SurgeryCraft_126_visual_trace.json';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
};
$('hospital-tab').onclick=()=>{
  root.classList.add('hospital-mode');$('hospital-tab').classList.add('active');$('anatomy-tab').classList.remove('active');state.playing=false;updateTimeline();
  if(!hospitalLoaded){$('hospital-frame').srcdoc=hospitalHtml;hospitalLoaded=true;}
  record('open-hospital');
};
$('anatomy-tab').onclick=()=>{root.classList.remove('hospital-mode');$('hospital-tab').classList.remove('active');$('anatomy-tab').classList.add('active');resize();record('open-anatomy');};

let lastTime=performance.now();
function animate(now){
  requestAnimationFrame(animate);const dt=(now-lastTime)/1000;lastTime=now;
  if(root.classList.contains('hospital-mode'))return;
  if(state.playing){const before=stageIndex();const result=tick(state,dt);state=result.state;if(result.blocked){status(tr('gate'),5000);record('gate-paused');}if(stageIndex()!==before){selected=stages[stageIndex()].focus;liverOverride=false;updateStructureList();updateStructureCard();record('stage',{stage:stages[stageIndex()].id});}updateTimeline();updateVisuals();if(state.time>=7)status(tr('completed'));}
  if(cameraTween){camera.position.lerp(cameraTween.position,.075);controls.target.lerp(cameraTween.target,.075);if(camera.position.distanceTo(cameraTween.position)<.002)cameraTween=null;}
  controls.update();
  if(loaded){
    const candidates=meshes.filter(m=>m.userData.structureId===selected&&m.visible&&(!m.parent||m.parent.visible));
    selectionBox.makeEmpty();for(const mesh of candidates)selectionBox.expandByObject(mesh);
    const label=$('picked-label');label.classList.toggle('hidden',!showLabels||selectionBox.isEmpty());
    if(showLabels&&!selectionBox.isEmpty()){
      const point=selectionBox.getCenter(new THREE.Vector3()).project(camera);
      label.textContent=nameOf(selected);label.style.left=`${THREE.MathUtils.clamp((point.x*.5+.5)*container.clientWidth+16,10,container.clientWidth-150)}px`;
      label.style.top=`${THREE.MathUtils.clamp((-point.y*.5+.5)*container.clientHeight,100,container.clientHeight-100)}px`;
    }
  }
  if(statusUntil&&now>statusUntil){statusUntil=0;status(state.laterality==='case'?tr('ready'):tr('compareNote'));}
  renderer.render(scene,camera);
}
translate();status(tr('loading'));requestAnimationFrame(animate);
