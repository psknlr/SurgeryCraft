"""BodyParts3D reference organ surfaces adapted in Blender 4.5 LTS.

blender -b -t 2 --python tools/blender/build_abdomen_1654623.py
Axes in Blender: +X patient left, -Y anterior, +Z cranial. glTF: +Y up.
Organ surfaces: DBCLS / CC BY 4.0; other teaching geometry: MIT. Not patient-derived.
"""
from pathlib import Path
import bpy
import math
import json
import hashlib
import sys
from mathutils import Vector
sys.path.insert(0,str(Path(__file__).resolve().parent))
from anatomy_surfaces import atlas_surface,tissue

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'content' / 'assets' / 'models'
BLENDS = ROOT / 'content' / 'assets' / 'blender'
OUT.mkdir(parents=True, exist_ok=True)
BLENDS.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)


def material(name, color, roughness=.38, metallic=0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (*color, 1)
    bsdf.inputs['Roughness'].default_value = roughness
    bsdf.inputs['Metallic'].default_value = metallic
    if not metallic:
        bsdf.inputs['Subsurface Weight'].default_value = .07
    return m


M = {
    'liver': material('Liver capsule', (.22, .038, .027), .33),
    'gallbladder': material('Gallbladder serosa', (.18, .245, .095), .28),
    'duct': material('Biliary ducts', (.48, .36, .19), .37),
    'artery': material('Arteries', (.40, .07, .055), .34),
    'vein': material('Portal vein', (.15, .105, .14), .38),
    'stomach': material('Gastric serosa', (.52, .24, .19), .39),
    'pancreas': material('Pancreas', (.83, .55, .35), .48),
    'bowel': material('Duodenum', (.76, .48, .36), .43),
    'spleen': material('Spleen', (.36, .105, .19), .37),
    'wall': material('Posterior abdominal context', (.28, .12, .115), .66),
    'bed': material('Liver bed teaching patch', (.48, .18, .12), .53),
    'steel': material('Surgical steel', (.58, .66, .70), .23, .86),
    'clip': material('Titanium clip / schematic gold tint', (.77, .63, .34), .24, .88),
    'grip': material('Instrument insulation', (.045, .055, .065), .40),
    'bag': material('Specimen bag teaching mesh', (.63, .77, .78), .40),
}


def finish(obj, name, structure, mat, parent=None):
    obj.name = name
    obj['structureId'] = structure
    obj['geometryKind'] = 'authored-schematic-not-patient-derived'
    if mat:
        obj.data.materials.append(mat)
    if parent:
        obj.parent = parent
    if obj.type == 'MESH':
        for polygon in obj.data.polygons:
            polygon.use_smooth = True
    return obj


def group(name, structure):
    obj = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(obj)
    obj['structureId'] = structure
    return obj


def sphere(name, centre, scale, mat, structure, parent=None):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, location=centre)
    obj = bpy.context.object
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return finish(obj, name, structure, mat, parent)


def tube(name, points, radius, mat, structure, parent=None):
    curve = bpy.data.curves.new(name, 'CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 16
    curve.bevel_depth = radius
    curve.bevel_resolution = 4
    curve.use_fill_caps = True
    spline = curve.splines.new('BEZIER')
    spline.bezier_points.add(len(points) - 1)
    for p, value in zip(spline.bezier_points, points):
        p.co = value
        p.handle_left_type = 'AUTO'
        p.handle_right_type = 'AUTO'
    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.convert(target='MESH')
    obj.select_set(False)
    return finish(obj, name, structure, mat, parent)


def capsule_surface(name, centre, radii, kind, mat, structure):
    # Smooth closed, deformed surfaces. Large-scale shape is deliberately schematic.
    vertices, faces = [], []
    nu, nv = 72, 36
    for j in range(nv + 1):
        theta = math.pi * (j + .002) / (nv + .004)
        for i in range(nu):
            phi = 2 * math.pi * i / nu
            sx, sy, sz = math.sin(theta)*math.cos(phi), math.sin(theta)*math.sin(phi), math.cos(theta)
            if kind == 'liver':
                breadth = .86 + .15*sx
                x = radii[0] * sx
                y = radii[1] * sy * breadth + .10*sx
                z = radii[2] * sz * (.88+.12*sx) + .12*sx
                if sz < -.15 and sy < 0:
                    z += .10*math.exp(-((sx+.12)/.32)**2)
            else:
                x, y, z = radii[0]*sx, radii[1]*sy, radii[2]*sz
            vertices.append((centre[0]+x, centre[1]+y, centre[2]+z))
    for j in range(nv):
        for i in range(nu):
            a=j*nu+i; b=j*nu+(i+1)%nu; c=(j+1)*nu+(i+1)%nu; d=(j+1)*nu+i
            faces.append((a,b,c,d))
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata(vertices,[],faces)
    mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    bpy.context.collection.objects.link(obj)
    finish(obj,name,structure,mat)
    # Subtle per-vertex colour variation is exportable, unlike a procedural shader texture.
    color=mesh.color_attributes.new(name='TissueVariation',type='FLOAT_COLOR',domain='CORNER')
    for loop in mesh.loops:
        v=mesh.vertices[loop.vertex_index].co
        k=.97+.028*math.sin(v.x*19+v.y*11)*math.cos(v.z*17)
        color.data[loop.index].color=tuple(c*k for c in mat.diffuse_color[:3])+(1,)
    attr=mat.node_tree.nodes.new('ShaderNodeVertexColor')
    attr.layer_name='TissueVariation'
    mat.node_tree.links.new(attr.outputs['Color'],mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
    return obj


# A cutaway context, not a segmented body surface.
wall = sphere('AbdominalContext', (0,1.65,1.2), (2.65,.35,2.0), M['wall'], 'context')
liver = atlas_surface('Liver',['FJ2816','FJ2818','FJ2819','FJ2820','FJ2821','FJ2822','FJ2409','FJ2823','FJ2824'],M['liver'],'liver',merge=True)
spleen=sphere('Spleen',(-1.55,.30,1.55),(.24,.34,.52),M['spleen'],'spleen')
for v in spleen.data.vertices:
    v.co.x+=.09*(v.co.z/.52)**2
tissue(spleen,M['spleen'])
stomach=atlas_surface('Stomach',['FJ2564'],M['stomach'],'stomach')
atlas_surface('Duodenum',['FJ2573'],M['bowel'],'duodenum')
pancreas=atlas_surface('Pancreas',['FJ1895'],M['pancreas'],'pancreas')

# Gallbladder body and its neck are one detachable group. The body is a smooth pear.
gb = group('GallbladderAssembly','gallbladder')
gall=atlas_surface('Gallbladder',['FJ2817'],M['gallbladder'],'gallbladder',gb)
neck=tube('GallbladderNeck',[(.755,-.315,1.375),(.72,-.42,1.40),(.65,-.52,1.35)],.045,M['gallbladder'],'gallbladder',gb)
tissue(neck,M['gallbladder'])
sphere('LiverBed',(.97,-.425,1.18),(.25,.035,.38),M['bed'],'liver-bed')

# The junction topology and calibre are generic teaching choices, not source patient findings.
tube('CommonHepaticDuct',[(.26,-.46,1.80),(.26,-.49,1.55),(.30,-.50,1.25)],.050,M['duct'],'common-hepatic-duct')
tube('LeftHepaticDuct',[(.26,-.46,1.80),(-.03,-.35,1.91),(-.30,-.22,1.97)],.038,M['duct'],'hepatic-branches')
tube('RightHepaticDuct',[(.26,-.46,1.80),(.57,-.31,1.95),(.88,-.15,2.03)],.040,M['duct'],'hepatic-branches')
tube('CommonBileDuct',[(.30,-.50,1.25),(.26,-.47,1.01),(.18,-.25,.74),(.05,-.10,.57)],.052,M['duct'],'common-bile-duct')
tube('CysticDuctRetained',[(.30,-.50,1.25),(.41,-.53,1.20),(.49,-.54,1.21)],.037,M['duct'],'cystic-duct')
tube('CysticDuctDivision',[(.49,-.54,1.21),(.55,-.54,1.23)],.037,M['duct'],'cystic-duct')
tube('CysticDuctDistal',[(.55,-.54,1.23),(.62,-.53,1.27),(.65,-.52,1.35)],.037,M['duct'],'cystic-duct',gb)
tube('HepaticArtery',[(.04,-.26,.78),(.06,-.28,1.15),(.10,-.29,1.54),(.46,-.20,1.85),(.88,-.10,1.94)],.043,M['artery'],'hepatic-artery')
tube('CysticArteryRetained',[(.15,-.30,1.64),(.36,-.45,1.61),(.48,-.50,1.54)],.024,M['artery'],'cystic-artery')
tube('CysticArteryDivision',[(.48,-.50,1.54),(.54,-.51,1.51)],.024,M['artery'],'cystic-artery')
tube('CysticArteryDistal',[(.54,-.51,1.51),(.66,-.48,1.46),(.79,-.37,1.31)],.024,M['artery'],'cystic-artery',gb)
tube('PortalVein',[(.02,.11,.66),(.07,.08,1.18),(.13,.07,1.60),(.50,.12,1.84)],.087,M['vein'],'portal-vein')

# Clips are displayed later by the viewer. Their count/spacing is not a clinical instruction.
clips=group('Clips','clips')
for id, position in enumerate([(.425,-.54,1.205),(.593,-.54,1.255),(.395,-.48,1.59),(.615,-.52,1.475)]):
    x,y,z=position
    tube('Clip'+str(id),[(x-.025,y-.055,z-.043),(x+.035,y-.055,z-.043),(x+.035,y-.055,z+.043),(x-.025,y-.055,z+.043)],.012,M['clip'],'clips',clips)

# Original laparoscopic instruments; the application positions them for the animations.
def instrument(name):
    root=group(name,'instrument')
    tube(name+'Shaft',[(0,0,-3.8),(0,0,-.10)],.024,M['steel'],'instrument',root)
    sphere(name+'Collar',(0,0,-.11),(.045,.045,.07),M['grip'],'instrument',root)
    for side in [-1,1]:
        tube(name+'Jaw'+str(side),[(side*.025,0,-.10),(side*.045,0,-.015),(side*.018,0,.08)],.011,M['steel'],'instrument',root)
    root.location=(3,0,0) # moved into the field by the web viewer
    return root
instrument('Grasper')
instrument('ClipApplier')
instrument('Dissector')

# A conceptual extraction pouch, deliberately an open wire basket rather than a physical film model.
bag=group('SpecimenBag','specimen-bag')
for i in range(10):
    angle=i*math.tau/10
    tube('BagRib'+str(i),[(.38*math.cos(angle),.29*math.sin(angle),.25),(.30*math.cos(angle),.22*math.sin(angle),-.12),(0,0,-.35)],.009,M['bag'],'specimen-bag',bag)
tube('BagRim',[(.38*math.cos(i*math.tau/16),.29*math.sin(i*math.tau/16),.25) for i in range(17)],.015,M['bag'],'specimen-bag',bag)
bag.location=(3,0,0)

# Editor camera and lights; excluded from the web GLB.
bpy.ops.object.camera_add(location=(0,-7,2.9))
camera=bpy.context.object
camera.name='TeachingCamera'
direction=Vector((.2,-.25,1.25))-camera.location
camera.rotation_euler=direction.to_track_quat('-Z','Y').to_euler()
camera.data.lens=52
bpy.context.scene.camera=camera
for name,location,power,size in [('Key',(-3,-4,5),650,4),('Fill',(4,-2,3),400,3),('Rim',(0,3,4),600,3)]:
    bpy.ops.object.light_add(type='AREA',location=location)
    light=bpy.context.object
    light.name=name;light.data.energy=power;light.data.shape='DISK';light.data.size=size
    light.rotation_euler=(Vector((0,0,1.2))-light.location).to_track_quat('-Z','Y').to_euler()
scene=bpy.context.scene
scene.world.color=(.025,.035,.045)
scene.render.resolution_x=1400;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene['provenance']='BodyParts3D / DBCLS CC BY 4.0 organ surfaces adapted in Blender; original schematic ducts/instruments. Not a patient mesh.'
scene['animation_note']='Frames 1–337: 8 authored teaching stages; no tissue physics. Web playback adds a learning pause.'
scene.render.fps=24
scene.frame_start=1
scene.frame_end=337
for i,name in enumerate(['Orientation','Exposure','Identification','Safety pause','Clipping','Division','Separation','Extraction']):
    scene.timeline_markers.new(name,frame=1+i*48)

def smooth(value):
    x=max(0,min(1,value))
    return x*x*(3-2*x)

def visible_at(obj,visible,frame):
    obj.hide_render=not visible
    obj.hide_viewport=not visible
    obj.keyframe_insert(data_path='hide_render',frame=frame)
    obj.keyframe_insert(data_path='hide_viewport',frame=frame)

# Editable Blender animation follows the same authored trajectory as the web viewer.
for frame in range(1,338,2):
    t=(frame-1)/48
    separated=smooth(t-5)
    extracted=smooth((t-6.2)/.8)
    exposed=smooth(t)
    liver.location=(0,.22*exposed,.48*exposed)
    liver.keyframe_insert(data_path='location',frame=frame)
    visible_at(bpy.data.objects['LiverBed'],t>=5,frame)
    offset=Vector((.12*separated,-(.52*separated+.65*extracted),.10*separated+.55*extracted))
    gb.location=offset
    gb.rotation_euler[1]=.16*separated
    gb.keyframe_insert(data_path='location',frame=frame)
    gb.keyframe_insert(data_path='rotation_euler',frame=frame)
    for child in gb.children:
        visible_at(child,extracted<.99,frame)
    for name in ['CysticDuctDivision','CysticArteryDivision']:
        visible_at(bpy.data.objects[name],t<5,frame)
    for child in clips.children:
        distal=child.name in ['Clip1','Clip3']
        child.location=offset if distal else (0,0,0)
        child.rotation_euler[1]=.16*separated if distal else 0
        child.keyframe_insert(data_path='location',frame=frame)
        child.keyframe_insert(data_path='rotation_euler',frame=frame)
        visible_at(child,t>=4 and (not distal or extracted<.99),frame)
    bag.location=offset+Vector((.97,-.54,1.02))
    bag.scale=(.85,)*3
    bag.keyframe_insert(data_path='location',frame=frame)
    for child in bag.children:
        visible_at(child,t>=6.2 and extracted<.99,frame)
    for name,tip,entry,shown in [
        ('Grasper',Vector((1.02,-.70,1.05))+offset,Vector((-1.3,-3.5,0)),1<=t<7),
        ('ClipApplier',Vector((.53,-.58,1.23)),Vector((1.7,-3.5,.2)),4<=t<5),
        ('Dissector',Vector((.53,-.58,1.51)),Vector((1.7,-3.5,.2)),5<=t<6.5),
    ]:
        obj=bpy.data.objects[name]
        direction=(tip-entry).normalized()
        obj.location=tip-direction*.08
        obj.rotation_euler=direction.to_track_quat('Z','Y').to_euler()
        obj.keyframe_insert(data_path='location',frame=frame)
        obj.keyframe_insert(data_path='rotation_euler',frame=frame)
        for child in obj.children:
            visible_at(child,shown,frame)
scene.frame_set(1)
bpy.context.view_layer.update()
blend=BLENDS/'cmcr-1654623-mirror-abdomen.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(blend))
# Disabled viewport objects have stale matrix_world values. Export an evaluated
# neutral frame with all objects enabled; the saved .blend keeps its keyframes.
for obj in scene.objects:
    obj.hide_viewport=False
    obj.update_tag(refresh={'OBJECT'})
bpy.context.view_layer.update()
glb=OUT/'cmcr-1654623-mirror-abdomen.glb'
bpy.ops.export_scene.gltf(filepath=str(glb),export_format='GLB',export_cameras=False,export_lights=False,
                          export_extras=True,export_animations=False,export_current_frame=True,
                          export_copyright='Organ surfaces: BodyParts3D, © DBCLS, CC BY 4.0; other schematic geometry: SurgeryCraft MIT. Not patient-derived.')
manifest=dict(schema='surgerycraft/anatomy-asset@1',caseId='cmcr-1654623',blender=bpy.app.version_string,
              glb=glb.name,sha256=hashlib.sha256(glb.read_bytes()).hexdigest(),blend=blend.name,
              axes='Blender: +X patient left, -Y anterior, +Z cranial; glTF: +X patient left, +Y cranial, +Z anterior',
              license='BodyParts3D organ surfaces CC BY 4.0; original code and schematic additions MIT',geometry='adapted reference anatomy; not patient-specific',
              sourceFacts=['Source CT describes liver/gallbladder on patient left and stomach/spleen on patient right'],
              authored=['mirror adaptation, surface processing and materials','duct/vessel topology and calibre','instrument and clip geometry'],
              referenceOrgans=['liver','gallbladder','stomach','duodenum','pancreas'],
              sourceAttribution='BodyParts3D, © The Database Center for Life Science licensed under CC Attribution 4.0 International',
              animation='Editable teaching keyframes in .blend; web uses the same authored trajectory with a learning pause',
              meshes=sum(o.type=='MESH' for o in scene.objects),
              polygons=sum(len(o.data.polygons) for o in scene.objects if o.type=='MESH'))
(OUT/'cmcr-1654623-anatomy.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('MODEL_BUILT',json.dumps(manifest))
