"""Fetch only selected anatomy meshes from the official DBCLS archive by ZIP ranges."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,struct,zlib,json,hashlib
URL='https://dbarchive.biosciencedbc.jp/data/bodyparts3d/LATEST/partof_BP3D_4.0_obj_99.zip'
OUT=Path(__file__).resolve().parents[2]/'content/assets/source/bodyparts3d'
OUT.mkdir(parents=True,exist_ok=True)
def fetch(a,b):
    with urllib.request.urlopen(urllib.request.Request(URL,headers={'Range':f'bytes={a}-{b}'}),timeout=60) as r:
        assert r.status==206
        return r.read()
tail=fetch(64822969,64888504)
v=struct.unpack_from('<4s4H2IH',tail,tail.rfind(b'PK\x05\x06'))
central=fetch(v[6],v[6]+v[5]-1)
entries={};i=0
while central[i:i+4]==b'PK\x01\x02':
    v=struct.unpack_from('<4s6H3I5H2I',central,i)
    n,ex,co=v[10:13];name=central[i+46:i+46+n].decode()
    entries[Path(name).stem]=(name,v[8],v[7],v[16])
    i+=46+n+ex+co
ids=['FJ2816','FJ2818','FJ2819','FJ2820','FJ2821','FJ2822','FJ2409','FJ2823','FJ2824',
     'FJ2564','FJ2817','FJ2573','FJ1895','FJ2561']
def download(id):
    if id not in entries:return {'id':id,'missing':True}
    name,size,crc,offset=entries[id]
    # ZIP local header plus file name/extras then the compressed payload.
    data=fetch(offset,offset+size+4096)
    header=struct.unpack_from('<4s5H3I2H',data)
    start=30+header[9]+header[10]
    raw=zlib.decompress(data[start:start+size],-15)
    assert zlib.crc32(raw)==crc
    (OUT/(id+'.obj')).write_bytes(raw)
    result={'id':id,'archiveEntry':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    print(result,flush=True)
    return result
with ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(download,ids))
(OUT/'sources.json').write_text(json.dumps({'source':URL,'version':'BodyParts3D 4.0 PART-OF, 99% reduction',
 'attribution':'BodyParts3D, © The Database Center for Life Science licensed under CC Attribution 4.0 International',
 'license':'https://creativecommons.org/licenses/by/4.0/','licenseEvidence':'https://dbarchive.biosciencedbc.jp/en/bodyparts3d/lic.html',
 'meshes':results},ensure_ascii=False,indent=2),encoding='utf-8')
