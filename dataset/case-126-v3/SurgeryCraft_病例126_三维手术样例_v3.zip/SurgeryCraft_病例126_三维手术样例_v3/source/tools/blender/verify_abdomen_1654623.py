"""Run in Blender: -b content/assets/blender/...blend --python this_file."""
from pathlib import Path
import bpy
import json

scene=bpy.context.scene
assert len(scene.timeline_markers)==8
assert scene.frame_end==337
objects=bpy.data.objects
assert sum(o.type=='MESH' for o in scene.objects)==48
checks=[]
for frame in [1,193,241,289,337]:
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    assert not objects['CommonBileDuct'].hide_render
    assert not objects['CommonHepaticDuct'].hide_render
    assert not objects['HepaticArtery'].hide_render
    assert not objects['PortalVein'].hide_render
    if frame>=241:
        assert objects['CysticDuctDivision'].hide_render
        assert objects['CysticArteryDivision'].hide_render
    checks.append({'frame':frame,'mainDuctAndVesselsPreserved':True,
                   'gallbladderHidden':objects['Gallbladder'].hide_render,
                   'gallbladderOffset':list(objects['GallbladderAssembly'].location)})
assert objects['Gallbladder'].hide_render
assert objects['GallbladderAssembly'].location.z>.6
root=Path(__file__).resolve().parents[2]
out=root/'output'/'surgery-1654623'
out.mkdir(parents=True,exist_ok=True)
report={'passed':True,'blender':bpy.app.version_string,'meshes':48,'markers':8,'frames':337,'checks':checks}
(out/'blender-validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('BLENDER_CHECKS',json.dumps(report))
