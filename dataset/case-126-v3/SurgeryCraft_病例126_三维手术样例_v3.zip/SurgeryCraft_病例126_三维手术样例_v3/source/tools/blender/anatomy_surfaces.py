"""Adapt DBCLS reference surfaces to the mirrored teaching scene (CC BY 4.0).
No patient imaging or patient-specific reconstruction is performed.
"""
from pathlib import Path
import bpy,math,bmesh
from mathutils import Vector,noise
SOURCE=Path(__file__).resolve().parents[2]/'content/assets/source/bodyparts3d'
SCALE=.0143
OFFSET=Vector((.337,1.65,-14.22))

def tissue(obj,mat):
    mesh=obj.data
    attr=mesh.color_attributes.new(name='TissueVariation',type='FLOAT_COLOR',domain='CORNER')
    for loop in mesh.loops:
        p=mesh.vertices[loop.vertex_index].co
        n=noise.noise_vector(p*27)[0]*.08+noise.noise_vector(p*95)[1]*.035+noise.noise_vector(p*5)[2]*.09
        rgb=mat.diffuse_color[:3]
        attr.data[loop.index].color=tuple(max(.001,c*(1+n)) for c in rgb)+(1,)
    node=mat.node_tree.nodes.new('ShaderNodeVertexColor');node.layer_name=attr.name
    mat.node_tree.links.new(node.outputs['Color'],mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])

def atlas_surface(name,ids,mat,structure,parent=None,merge=False):
    vs=[];faces=[]
    for id in ids:
        offset=len(vs)
        for line in (SOURCE/(id+'.obj')).read_text().splitlines():
            words=line.split()
            if not words:continue
            if words[0]=='v':
                x,y,z=map(float,words[1:4]);vs.append(tuple(Vector((-x,y,z))*SCALE+OFFSET))
            elif words[0]=='f':
                # Reflecting the source's X axis reverses orientation.
                faces.append(tuple(offset+int(w.split('/')[0])-1 for w in reversed(words[1:])))
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(vs,[],faces);mesh.update()
    obj=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(obj)
    bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
    if merge:
        # Close atlas segment seams before union so partition boundaries do not
        # become fictitious scars on the liver capsule.
        bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.normal_update()
        for v in bm.verts:v.co+=v.normal*.035
        bm.to_mesh(mesh);bm.free()
        obj.data.remesh_voxel_size=.025
        bpy.ops.object.voxel_remesh()
        mod=obj.modifiers.new('Capsule continuity','SMOOTH');mod.factor=.70;mod.iterations=9
        bpy.ops.object.modifier_apply(modifier=mod.name)
    mod=obj.modifiers.new('Smooth anatomical surface','SUBSURF');mod.levels=1;mod.render_levels=1
    bpy.ops.object.modifier_apply(modifier=mod.name)
    obj.data.materials.clear();obj.data.materials.append(mat)
    for p in obj.data.polygons:p.use_smooth=True
    tissue(obj,mat)
    obj['structureId']=structure
    obj['geometryKind']='BodyParts3D reference anatomy; mirrored, smoothed and repositioned; not patient-specific'
    obj['sourceMeshes']=','.join(ids)
    obj['attribution']='BodyParts3D, © The Database Center for Life Science; CC BY 4.0'
    if parent:obj.parent=parent
    return obj
