/** Build a local teaching edition with the offline reference demonstration.
 * Normal server case APIs intentionally omit solutions. The local demo therefore bundles
 * this one authored case exactly like the engine's built-in teaching cases. Benchmark
 * agents still use the restricted session tool APIs; this teaching build is not a blind test.
 * No engine source code is patched; the temporary content copy is removed after building.
 */
import { readFile, writeFile, mkdir, unlink, rmdir, access } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';

const pack = fileURLToPath(new URL('../../', import.meta.url));
const engine = resolve(process.env.CLINICALCRAFT_DIR || join(pack, '..', 'ClinicalCraft'));
const bytes = await readFile(join(pack, 'content/cases/cmcr-1654623/case.json'));
const caseSha256 = createHash('sha256').update(bytes).digest('hex');
const out = join(pack, 'output/pilot-1654623');
const manifestPath = join(out, 'web-build.json');
const webIndexPath = join(engine, 'packages/web/dist/index.html');
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const exists = async path => access(path).then(() => true, () => false);
try {
  const old = JSON.parse(await readFile(manifestPath, 'utf8'));
  if (old.caseSha256 === caseSha256 && await exists(webIndexPath) && old.webIndexSha256 === digest(await readFile(webIndexPath))) {
    console.log('Local teaching web build is current.');
    process.exit(0);
  }
} catch { /* first build */ }
const staging = resolve(engine, 'packages/content/cases/cmcr-1654623');
const allowedParent = resolve(engine, 'packages/content/cases');
if (resolve(staging, '..') !== allowedParent) throw new Error('Unexpected staging target');
if (await exists(staging)) throw new Error('Refusing to overwrite an existing built-in case: ' + staging);
await mkdir(staging);
try {
  await writeFile(join(staging, 'case.json'), bytes);
  const build = spawnSync(process.execPath, [join(engine, 'node_modules/vite/bin/vite.js'), 'build'], {
    cwd: join(engine, 'packages/web'), stdio: 'inherit', windowsHide: true,
  });
  if (build.status !== 0) throw new Error('Teaching web build failed: ' + build.status);
  await mkdir(out, { recursive: true });
  await writeFile(manifestPath, JSON.stringify({ caseSha256, webIndexSha256: digest(await readFile(webIndexPath)), builtAt: new Date().toISOString(),
    edition: 'local-teaching-demo', referenceIncluded: true,
    assessmentBoundary: 'Not a blind evaluation web build. Never give this teaching bundle to agents under test.' }, null, 2) + '\n');
} finally {
  // Only the exact file and empty directory created above are removed, without recursive deletion.
  if (await exists(join(staging, 'case.json'))) await unlink(join(staging, 'case.json'));
  await rmdir(staging);
}
