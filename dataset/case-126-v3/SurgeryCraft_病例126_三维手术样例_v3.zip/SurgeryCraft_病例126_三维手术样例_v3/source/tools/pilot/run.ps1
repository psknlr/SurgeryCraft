﻿# Run the pilot with the sibling ClinicalCraft checkout and the local Node runtime.
param(
    [ValidateSet('Serve', 'Validate', 'Demo')][string]$Mode = 'Serve',
    [int]$Port = 8765,
    [string]$EngineDirectory = (Join-Path $PSScriptRoot '..\..\..\ClinicalCraft'),
    [switch]$OpenBrowser
)
$ErrorActionPreference = 'Stop'
$packRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$engineRoot = [IO.Path]::GetFullPath($EngineDirectory)
$bundledNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
$nodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
$nodeExe = if ($nodeCommand) { $nodeCommand.Source } else { $bundledNode }
if (-not (Test-Path -LiteralPath $nodeExe)) { throw 'Node.js 22+ is required.' }
if (-not (Test-Path -LiteralPath (Join-Path $engineRoot 'node_modules\tsx\dist\loader.mjs'))) {
    throw "ClinicalCraft dependencies are missing. Install them in $engineRoot using npm ci. See docs/PILOT_1654623.md."
}
$outputDirectory = Join-Path $packRoot 'output\pilot-1654623'
[void][IO.Directory]::CreateDirectory($outputDirectory)
$casePath = Join-Path $packRoot 'content\cases\cmcr-1654623\case.json'
Push-Location -LiteralPath $engineRoot
try {
    if ($Mode -eq 'Validate') {
        & $nodeExe --import tsx --conditions=source packages/cli/src/bin.ts cases validate $casePath --strict --cwd $packRoot
        if ($LASTEXITCODE -ne 0) { throw 'Case validation failed.' }
        & $nodeExe --import tsx --conditions=source packages/cli/src/bin.ts cases verify cmcr-1654623 --cwd $packRoot
        if ($LASTEXITCODE -ne 0) { throw 'Reference verification failed.' }
    } elseif ($Mode -eq 'Demo') {
        $env:CLINICALCRAFT_DIR = $engineRoot
        & $nodeExe --import tsx --conditions=source (Join-Path $packRoot 'tools\pilot\run.mjs')
        if ($LASTEXITCODE -ne 0) { throw 'Pilot checks failed; inspect output/pilot-1654623.' }
    } else {
        $env:CLINICALCRAFT_DIR = $engineRoot
        & $nodeExe (Join-Path $packRoot 'tools\pilot\prepare-web.mjs')
        if ($LASTEXITCODE -ne 0) { throw 'Teaching web build failed.' }
        $url = "http://127.0.0.1:$Port/"
        $probe = $url + 'api/content/cases/cmcr-1654623'
        $ready = $false
        try { $null = Invoke-WebRequest -Uri $probe -UseBasicParsing -TimeoutSec 2; $ready = $true } catch {}
        if (-not $ready) {
            $serverArgs = @('--import', 'tsx', '--conditions=source', 'packages/cli/src/bin.ts', 'serve', '--host', '127.0.0.1', '--port', "$Port", '--cwd', ('"' + $packRoot + '"'))
            $server = Start-Process -FilePath $nodeExe -ArgumentList $serverArgs -WorkingDirectory $engineRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $outputDirectory 'server.log') -RedirectStandardError (Join-Path $outputDirectory 'server-error.log')
            $server.Id | Set-Content -LiteralPath (Join-Path $outputDirectory 'server.pid')
            for ($attempt = 0; $attempt -lt 30; $attempt++) {
                Start-Sleep -Milliseconds 500
                try { $null = Invoke-WebRequest -Uri $probe -UseBasicParsing -TimeoutSec 2; $ready = $true; break } catch {}
                if ($server.HasExited) { break }
            }
        }
        if (-not $ready) { throw 'Server did not become ready. Inspect server-error.log or use a different -Port.' }
        Write-Output "Pilot ready: $url"
        Write-Output 'Search the case library for 84 and select the 84-year-old man. Use the offline demonstration to watch the full case.'
        if ($OpenBrowser) { Start-Process $url }
    }
} finally { Pop-Location }
