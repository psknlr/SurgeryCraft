"""Zip the reviewed v2 handoff directory and verify its contents."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
import json

root=Path(__file__).resolve().parents[2]
delivery=root/'output'/'delivery-1654623-v3'
manifest=json.loads((delivery/'manifest.json').read_text(encoding='utf-8'))
assert sha256((delivery/manifest['entry']).read_bytes()).hexdigest()==manifest['htmlSha256']
checksums=[]
for path in sorted(delivery.rglob('*')):
    if path.is_file() and path.name!='文件清单.sha256':
        assert path.suffix.lower() not in ['.pdf','.exe','.dll','.blend1']
        assert path.name not in ['settings.local.json','.env']
        checksums.append(sha256(path.read_bytes()).hexdigest()+'  '+path.relative_to(delivery).as_posix())
(delivery/'文件清单.sha256').write_text('\n'.join(checksums)+'\n',encoding='utf-8')
target=root/'output'/'SurgeryCraft_病例126_三维手术样例_v3.zip'
with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(delivery.rglob('*')):
        if path.is_file():
            archive.write(path,Path('SurgeryCraft_病例126_三维手术样例_v3')/path.relative_to(delivery))
with ZipFile(target) as archive:
    assert archive.testzip() is None
    data=archive.read('SurgeryCraft_病例126_三维手术样例_v3/'+manifest['entry'])
    assert sha256(data).hexdigest()==manifest['htmlSha256']
    count=len(archive.infolist())
print(json.dumps({'zip':str(target),'files':count,'bytes':target.stat().st_size,
                  'crc':'pass','htmlSha256':manifest['htmlSha256']},ensure_ascii=False))
