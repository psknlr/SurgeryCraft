/** Build a single offline HTML and a small collaborator handoff folder.
 * Uses the existing engine standalone builder; no PDF, source figures, credentials,
 * machine-specific runtime, or node_modules are included in the handoff.
 */
import { readFile, writeFile, mkdir, unlink, rmdir, readdir, copyFile, access } from 'node:fs/promises';
import { resolve, join, relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const pack = fileURLToPath(new URL('../../', import.meta.url));
const engine = resolve(process.env.CLINICALCRAFT_DIR || join(pack, '..', 'ClinicalCraft'));
const contentRoot = resolve(engine, 'packages/content');
const delivery = join(pack, 'output', 'delivery-1654623');
const htmlName = 'SurgeryCraft_病例126_离线演示.html';
const createdFiles = [];
const createdDirectories = [];
const exists = path => access(path).then(() => true, () => false);
const sha256 = data => createHash('sha256').update(data).digest('hex');
await mkdir(delivery, { recursive: true });

async function stage(source, relativeTarget) {
  const target = resolve(contentRoot, relativeTarget);
  if (relative(contentRoot, target).startsWith('..')) throw new Error('Unsafe staging path');
  if (await exists(target)) throw new Error('Refusing to overwrite engine content: ' + target);
  const parent = dirname(target);
  if (!await exists(parent)) { await mkdir(parent, { recursive: true }); createdDirectories.push(parent); }
  await copyFile(source, target);
  createdFiles.push(target);
}
try {
  await stage(join(pack, 'content/cases/cmcr-1654623/case.json'), 'cases/cmcr-1654623/case.json');
  for (const folder of ['catalogs', 'templates', 'facilities']) {
    for (const name of await readdir(join(pack, 'content', folder))) {
      if (name.endsWith('.json')) await stage(join(pack, 'content', folder, name), join(folder, name));
    }
  }
  const web = join(engine, 'packages/web');
  for (const args of [
    [join(engine, 'node_modules/vite/bin/vite.js'), 'build', '--mode', 'standalone'],
    [join(web, 'scripts/inline-standalone.mjs'), '--no-local-assets'],
  ]) {
    const result = spawnSync(process.execPath, args, { cwd: web, stdio: 'inherit', windowsHide: true });
    if (result.status !== 0) throw new Error('Standalone build failed: ' + result.status);
  }
  let html = await readFile(join(web, 'dist-standalone/ClinicalCraft.html'), 'utf8');
  if (/<script\b[^>]*\bsrc=/i.test(html) || /<link\b[^>]*rel="stylesheet"[^>]*href=/i.test(html)) {
    throw new Error('The standalone file still contains external code or styles');
  }
  if (html.includes('id="cc-local-assets"')) throw new Error('Local-only media must not be embedded');
  const engineReadme = await readFile(join(engine, 'README.md'), 'utf8');
  const licenseSection = engineReadme.match(/## [^\n]*(?:Licen[cs]e|Copyright|许可)[^\n]*\n[\s\S]*?(?=\n## |$)/i)?.[0]
    || engineReadme.split('\n').filter(line => /MIT|copyright|licen[cs]e/i.test(line)).join('\n');
  const license = 'ClinicalCraft upstream declares MIT in package.json.\nSource: https://github.com/psknlr/ClinicalCraft\nNo standalone LICENSE file is present in the source snapshot. The following is the actual upstream notice:\n\n' + licenseSection;
  html = html.replace('<head>', `<head>\n<!-- SurgeryCraft case 126 local teaching demonstration.\nEngine: https://github.com/psknlr/ClinicalCraft\nContent pack: https://github.com/psknlr/SurgeryCraft\n${license.replace(/--/g, '- -')}\n-->`);
  await writeFile(join(delivery, htmlName), html);
  await writeFile(join(delivery, '来源与许可说明.txt'), license);
  await mkdir(join(delivery, 'third-party-licenses'), { recursive: true });
  for (const dependency of ['three', 'zod', '@anthropic-ai/sdk']) {
    for (const file of ['LICENSE', 'LICENSE.md', 'LICENSE.txt']) {
      const source = join(engine, 'node_modules', dependency, file);
      if (await exists(source)) {
        await copyFile(source, join(delivery, 'third-party-licenses', dependency.replace(/[\/@]/g, '_') + '-' + file));
        break;
      }
    }
  }
  const sourceFiles = ['README.md', '.clinicalcraft/settings.json', 'docs/PILOT_1654623.md',
    'content/cases/cmcr-1654623/case.json', 'content/cases/cmcr-1654623/evidence.json', 'content/cases/cmcr-1654623/README.md',
    'tools/case-gen/build_case_1654623.py', 'tools/pilot/run.mjs', 'tools/pilot/run.ps1',
    'tools/pilot/prepare-web.mjs', 'tools/pilot/package.mjs', 'start-pilot.cmd'];
  for (const folder of ['content/catalogs', 'content/templates', 'content/facilities', 'content/bench/surgerycraft-pilot-v1', '.clinicalcraft/skills']) {
    for (const name of await readdir(join(pack, folder))) {
      if (name.endsWith('.json')) sourceFiles.push(join(folder, name));
    }
  }
  for (const file of sourceFiles) {
    const target = join(delivery, 'source', file);
    await mkdir(dirname(target), { recursive: true });
    await copyFile(join(pack, file), target);
  }
  for (const [file, destination] of [
    ['summary.json', '验证结果.json'], ['clinical-checks.json', 'clinical-checks.json'],
    ['reference-benchmark.md', 'reference-benchmark.md'], ['reference-benchmark.json', 'reference-benchmark.json'],
    ['scripted-benchmark.json', 'scripted-benchmark.json'], ['embodied/demo.md', '逐步示范记录.md'],
    ['embodied/trace.jsonl', 'trace.jsonl'], ['reference-actions.json', 'reference-actions.json'],
    ['web-complete.png', '网页完成截图.png'],
  ]) {
    await copyFile(join(pack, 'output/pilot-1654623', file), join(delivery, destination));
  }
  await writeFile(join(delivery, '先读我.txt'), `SurgeryCraft 病例126：朋友交接包\n\n最快查看：\n1. 解压本ZIP。\n2. 用Chrome或Edge打开“${htmlName}”。这一个HTML即可运行，不需要安装Node、Python、Blender，不需要API密钥或本机服务。\n3. 病例库搜索“84”，选择“上腹痛伴发热 · 84岁男性”。\n4. 场馆选择“IMPF 外科医院”，保留“实景模式”，进入世界。\n5. 点击“示范接诊”→“开始并回到世界观看”，或自行操作。\n\n本文件自带场景、病例、代码与离线参考示范。若聊天软件只显示代码，请先保存到电脑，再使用浏览器打开。需要支持WebGL的桌面浏览器。\n\n继续开发：\nsource/ 是本轮内容与工具的副本，不含ClinicalCraft引擎及node_modules；协作者可优先从SurgeryCraft仓库获取版本，再按source/docs/PILOT_1654623.md准备兼容引擎。source/start-pilot.cmd需要引擎，不是独立演示入口。\n\n结果说明：\n验证结果.json、逐步示范记录.md和trace.jsonl记录本机实际运行。100分是已知参考脚本的流程检查结果，不是实际大模型的医学成绩。\n当前完成的是现有三维医院中的病例流程样例，未制作患者级Blender重建，未模拟组织切割、缝合或麻醉给药，尚未经过临床专家审核。\n教学演示HTML带参考答案，不用于盲测模型。离线模式不调用付费模型。\n\n来源：\nClinicalCraft引擎：https://github.com/psknlr/ClinicalCraft（许可证见来源与许可说明.txt）\nSurgeryCraft内容包：https://github.com/psknlr/SurgeryCraft\n病例原文引文见source/content/cases/cmcr-1654623/README.md。原始PDF及原始医学图片未放入本交接包。\n`, 'utf8');
  await writeFile(join(delivery, 'manifest.json'), JSON.stringify({ caseId: 'cmcr-1654623',
    builtAt: new Date().toISOString(), entry: htmlName, htmlSha256: sha256(html),
    htmlBytes: Buffer.byteLength(html), offline: true, referenceIncluded: true, localSourceMediaIncluded: false }, null, 2) + '\n');
  console.log('DELIVERY', delivery, (Buffer.byteLength(html) / 1048576).toFixed(2) + ' MiB HTML');
} finally {
  for (const file of createdFiles.reverse()) await unlink(file);
  for (const dir of createdDirectories.reverse()) await rmdir(dir);
}
