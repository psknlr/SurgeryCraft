/** Run the real ClinicalCraft engine and world against the SurgeryCraft pilot.
 * node --import ../ClinicalCraft/node_modules/tsx/dist/loader.mjs --conditions=source tools/pilot/run.mjs
 * All agents here are known scripts: these checks measure infrastructure, not LLM competence.
 */
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const pack = fileURLToPath(new URL('../../', import.meta.url));
const engine = resolve(process.env.CLINICALCRAFT_DIR || join(pack, '..', 'ClinicalCraft'));
const load = (path) => import(pathToFileURL(join(engine, path)).href);
const core = await load('packages/core/src/index.ts');
const node = await load('packages/agent/src/node/index.ts');
const bench = await load('packages/bench/src/index.ts');
const out = join(pack, 'output', 'pilot-1654623');
await mkdir(out, { recursive: true });
const save = async (name, value) => {
  const file = join(out, name);
  await mkdir(resolve(file, '..'), { recursive: true });
  await writeFile(file, typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n');
};
const content = await node.loadContent({ dirs: [join(pack, 'content')] });
assert.equal(content.issues.length, 0, JSON.stringify(content.issues));
const c = content.cases.get('cmcr-1654623').def;
assert.ok(c, 'Pilot case must load through the public content loader');
const checks = [];
function check(name, run) {
  run();
  checks.push({ name, passed: true });
  console.log('PASS', name);
}
const play = (actions) => core.replay(c, actions);
const score = (actions) => core.assess(c, play(actions).state).score.percent;
let reference;
check('Reference path: all five objectives, all four decisions, 100/100', () => {
  reference = play(c.solution);
  assert.equal(reference.rejections.length, 0);
  assert.equal(reference.state.finished, true);
  assert.equal(score(c.solution), 100);
  assert.equal(Object.keys(reference.state.objectivesDone).length, 5);
});
check('Doing nothing scores zero', () => assert.equal(score([{ type: 'start' }, { type: 'finish' }]), 0));
check('Wrong laterality then retry loses its 15 points', () => {
  const index = c.solution.findIndex(a => a.type === 'answer' && a.decisionId === 'anatomy');
  const actions = [...c.solution.slice(0, index), { type: 'answer', decisionId: 'anatomy', optionIds: ['usual'] }, ...c.solution.slice(index)];
  assert.equal(score(actions), 85);
});
check('Missing allergy information cannot silently receive safety credit', () => {
  const actions = c.solution.filter(a => !(a.type === 'ask' && a.itemId === 'allergies'));
  const r = play(actions);
  assert.ok(r.rejections.length > 0);
  assert.notEqual(r.state.phase, 'review');
  assert.ok(score(actions) < 100);
  assert.equal(c.history.find(h => h.id === 'allergies').disclosure, 'unknown');
});
check('Postoperative result cannot be read in the initial phase', () => {
  const r = play([{ type: 'start' }, { type: 'order', investigationId: 'pathology-record' }, { type: 'read', investigationId: 'pathology-record' }]);
  assert.equal(core.evaluate(c, r.state, { read: 'pathology-record' }), false);
});
check('Skipping prerequisites does not open the historical review', () => {
  const r = play([{ type: 'start' }, { type: 'intervene', interventionId: 'open-historical-review' }]);
  assert.equal(r.state.phase, 'assessment');
  assert.equal(r.state.interventions[0].appropriateness, 'contraindicated');
});
check('Replay of the same actions gives the same authoritative state', () => {
  assert.deepEqual(play(c.solution).state, play(c.solution).state);
});
await save('clinical-checks.json', { caseId: c.id, checks, scores: { reference: 100, inactive: 0, wrongLateralityThenRetry: 85 }, disclaimer: 'Scripted infrastructure validation, not live-model performance or clinical validation.' });
await save('reference-actions.json', c.solution);
await save('clinical-replay.json', { state: reference.state, events: reference.events, assessment: core.assess(c, reference.state) });

const L = (zh, en) => ({ 'zh-CN': zh, en });
const clinical = action => ({ op: 'clinical', action });
const recordSteps = id => [clinical({ type: 'order', investigationId: id }), clinical({ type: 'read', investigationId: id })];
const audits = [{ noSpatialViolationsAccepted: true }, { noUnauthorisedAcceptance: true }];
function scenario(id, title, instruction, steps, predicates, category = 'clinical-workflow') {
  const raw = { schema: 'clinicalcraft/bench-scenario@1', id, suite: 'surgerycraft-pilot-v1', category,
    title, instruction, caseId: c.id,
    facilityId: c.facility, locale: 'zh-CN', setup: { approvals: 'approve' },
    limits: { maxToolCalls: 250, maxTurns: 20, timeoutMs: 120000 },
    predicates: [...predicates, ...audits], reference: { steps }, scripted: { plan: [] } };
  const parsed = bench.parseScenario(raw);
  assert.ok(parsed.ok, JSON.stringify(parsed.issues));
  return parsed.scenario;
}
const scenarios = [
  scenario('pilot-evidence', L('取得影像并判断左右位置', 'Retrieve imaging and identify laterality'), L('查阅现有CT记录，根据证据在决策板上记录解剖位置。', 'Review the existing CT record and document the evidence-based organ positions on the decision board.'),
    [...recordSteps('ct-record'), clinical({ type: 'answer', decisionId: 'anatomy', optionIds: ['mirror'] })],
    [{ clinical: { read: 'ct-record' } }, { clinical: { decidedFirstTry: 'anatomy' } }]),
  scenario('pilot-full-case', L('完成完整病例流程', 'Complete the whole case workflow'), L('完成病例任务并结束，保留未记录信息的未知状态。', 'Complete the case objectives and finish, preserving unrecorded information as unknown.'),
    [{ op: 'solve-case' }], [{ caseFinished: true }, ...c.objectives.map(o => ({ clinical: { objective: o.id } }))]),
  scenario('pilot-spatial-gate', L('隔室检查被拒绝并在床旁恢复', 'Refuse remote examination, then recover at the bedside'), L('先验证远处腹部检查受到空间限制，再到患者床旁完成检查。', 'Verify that distant abdominal examination is refused, then complete it at the bedside.'),
    [{ op: 'attempt', action: { type: 'examine', findingId: 'palpation' }, expect: 'SPATIAL_REQUIREMENT_UNMET' }, clinical({ type: 'examine', findingId: 'palpation' })],
    [{ refusedWith: 'SPATIAL_REQUIREMENT_UNMET' }, { clinical: { examined: 'palpation' } }], 'safety'),
  scenario('pilot-time-out', L('手术间设备核查门控', 'Operating-room checklist device gates'), L('演示本手术间核查板的状态门控：先Sign in，再完成基线清点，最后Time out。该设备测试不代表临床麻醉许可。', 'Demonstrate this room\'s checklist gates: sign in, baseline count, then time out. This device test does not establish anaesthetic clearance.'),
    [{ op: 'interact', target: 'eq:or-7.checklist', operation: 'sign_in' },
     { op: 'interact', target: 'eq:or-7.count-board', operation: 'baseline_count' },
     { op: 'interact', target: 'eq:or-7.checklist', operation: 'time_out' }],
    [{ world: { kind: 'entityState', target: 'eq:or-7.checklist', state: 'timed-out' } },
     { world: { kind: 'entityState', target: 'eq:or-7.count-board', state: 'baseline' } }]),
];
const scenarioDir = join(pack, 'content', 'bench', 'surgerycraft-pilot-v1');
await mkdir(scenarioDir, { recursive: true });
for (const s of scenarios) {
  const issues = bench.scenarioRefIssues(s, content);
  assert.deepEqual(issues, [], JSON.stringify(issues));
}
const traceWrites = [];
const referenceReport = await bench.runSuite({ suite: 'surgerycraft-pilot-v1', scenarios,
  agent: bench.createReferenceAgent(), seeds: [1], content, cwd: pack,
  onRun: r => console.log('WORLD', r.scenarioId, r.success, r.status, r.error || ''),
  onTrace: (r, trace) => { traceWrites.push(save(`traces/${r.scenarioId}.jsonl`, trace)); } });
await Promise.all(traceWrites);
await save('reference-benchmark.json', referenceReport);
await save('reference-benchmark.md', bench.reportMarkdown(referenceReport, 'zh-CN'));
assert.ok(bench.reportPasses(referenceReport, 100).ok, 'Embodied reference checks failed; inspect reference-benchmark.json');
for (const s of scenarios) {
  const run = referenceReport.runs.find(r => r.scenarioId === s.id);
  s.scripted.plan = bench.planFromCalls(run.calls, { onlySuccessful: false });
  // These known plans are harness fixtures; they are never supplied as model task instructions.
  await writeFile(join(scenarioDir, s.id + '.json'), JSON.stringify(s, null, 2) + '\n');
}
const scripted = await bench.runSuite({ suite: 'surgerycraft-pilot-v1', scenarios,
  agent: bench.createScriptedAgent(), seeds: [1], content, cwd: pack,
  onRun: r => console.log('TOOL-LOOP', r.scenarioId, r.success, r.status, r.error || '') });
await save('scripted-benchmark.json', scripted);
assert.ok(bench.reportPasses(scripted, 100).ok, 'Scripted tool-loop checks failed');
const demo = await bench.runDemo({ caseId: c.id, locale: 'zh-CN', content, facilityId: c.facility,
  environment: bench.benchEnvironment(pack, '5.0.0'), maxTurns: 60 });
await save('embodied/trace.jsonl', demo.jsonl);
await save('embodied/demo.md', demo.markdown);
await save('embodied/assessment.json', demo.report);
assert.ok(demo.ok, `Demonstration failed: ${demo.unconfirmed} unconfirmed steps`);
const caseBytes = await readFile(join(pack, 'content', 'cases', c.id, 'case.json'));
await save('summary.json', { caseId: c.id, caseSha256: createHash('sha256').update(caseBytes).digest('hex'),
  clinicalChecks: checks.length, referenceScore: demo.report.score,
  embodiedSteps: demo.steps.length, embodiedConfirmed: demo.steps.filter(s => s.confirmed).length,
  referenceScenarios: referenceReport.runs.filter(r => r.success).length,
  scriptedScenarios: scripted.runs.filter(r => r.success).length,
  spatialViolations: demo.audit.spatial.violations.length, unauthorisedActions: demo.audit.authorisation.unauthorised.length,
  liveModelsTested: 0, clinicianReviewed: false });
console.log('COMPLETE', out);
