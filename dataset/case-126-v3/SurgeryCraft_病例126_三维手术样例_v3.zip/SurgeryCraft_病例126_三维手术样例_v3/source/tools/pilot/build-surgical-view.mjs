/** Build an offline anatomy + hospital teaching file and collaborator handoff. */
import { readFile, writeFile, mkdir, readdir, copyFile, stat, access } from 'node:fs/promises';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const pack = fileURLToPath(new URL('../../', import.meta.url));
const engine = resolve(process.env.CLINICALCRAFT_DIR || join(pack, '..', 'ClinicalCraft'));
const delivery = join(pack, 'output/delivery-1654623-v3');
const build = join(pack, 'output/surgical-view-build');
const entry = 'SurgeryCraft_病例126_三维手术样例.html';
const hash = data => createHash('sha256').update(data).digest('hex');
const exists = p => access(p).then(() => true, () => false);
function node(args) {
  const result = spawnSync(process.execPath, args, {cwd:pack, stdio:'inherit', windowsHide:true});
  if(result.status!==0)throw new Error('Build command failed: '+result.status);
}
// The old hospital file is a dependency; preserve its previous output for comparison.
if(!await exists(join(pack,'output/delivery-1654623/SurgeryCraft_病例126_离线演示.html')))node(['tools/pilot/package.mjs']);
node([join(engine,'node_modules/vite/bin/vite.js'),'build','--config','surgical-view/vite.config.mjs']);
let html = await readFile(join(build,'index.html'),'utf8');
const script = html.match(/<script\b[^>]*\bsrc="([^"]+)"[^>]*><\/script>/i);
const style = html.match(/<link\b[^>]*\brel="stylesheet"[^>]*\bhref="([^"]+)"[^>]*>/i);
if(!script||!style)throw new Error('Unexpected Vite output');
const js = await readFile(resolve(build,script[1]),'utf8');
const css = await readFile(resolve(build,style[1]),'utf8');
const {parseAst}=await import(pathToFileURL(join(engine,'node_modules/rollup/dist/es/parseAst.js')).href);
const ast=parseAst(js);
function checkImports(value) {
  if(!value||typeof value!=='object')return;
  if(['ImportDeclaration','ImportExpression','ExportAllDeclaration'].includes(value.type))throw new Error('Unresolved module import');
  for(const child of Object.values(value))if(Array.isArray(child))child.forEach(checkImports);else checkImports(child);
}
checkImports(ast);
if(!js.includes('data:model/gltf-binary;base64,'))throw new Error('GLB was not embedded');
html = html.replace(script[0],()=>'<script type="module">\n'+js.replace(/<\/script/gi,'<\\/script')+'\n</script>');
html = html.replace(style[0],()=>'<style>\n'+css+'\n</style>');
html = html.replace('<head>',`<head>\n<!-- BodyParts3D organ surfaces: DBCLS, CC BY 4.0; adapted in Blender. Other code/geometry MIT. Not patient-derived.\nIncludes ClinicalCraft hospital; notices supplied in the handoff.\nInteraction reference: https://github.com/FreedomIntelligence/BodyVista ; no BodyVista meshes used. -->`);
if(/<(?:script|link)\b[^>]*\b(?:src|href)=["'](?:\.\/|\/)/i.test(html))throw new Error('External code remains');
await mkdir(delivery,{recursive:true});
await writeFile(join(delivery,entry),html);
await writeFile(join(build,'preview.html'),html);
async function copy(source,target) {
  const info=await stat(source);
  if(info.isDirectory()) {
    await mkdir(target,{recursive:true});
    for(const name of await readdir(source))await copy(join(source,name),join(target,name));
  } else {await mkdir(dirname(target),{recursive:true});await copyFile(source,target);}
}
await copy(join(pack,'output/delivery-1654623/source'),join(delivery,'source'));
for(const file of ['README.md','docs/SURGICAL_VIEW_1654623.md','docs/PILOT_1654623.md',
  'content/cases/cmcr-1654623','content/assets/models/cmcr-1654623-mirror-abdomen.glb',
  'content/assets/models/cmcr-1654623-anatomy.json','content/assets/blender/cmcr-1654623-mirror-abdomen.blend',
  'content/assets/models/LICENSE-surgerycraft-anatomy.txt','tools/blender/build_abdomen_1654623.py','tools/blender/verify_abdomen_1654623.py',
  'content/assets/source/bodyparts3d','tools/blender/anatomy_surfaces.py','tools/blender/fetch_anatomy_reference.py','surgical-view','tools/pilot/build-surgical-view.mjs','tools/pilot/verify-surgical-view.mjs','tools/pilot/package-surgical-view.py']) {
  await copy(join(pack,file),join(delivery,'source',file));
}
await copy(join(pack,'output/delivery-1654623/third-party-licenses'),join(delivery,'third-party-licenses'));
await copyFile(join(pack,'output/delivery-1654623/来源与许可说明.txt'),join(delivery,'医院引擎来源与许可.txt'));
await copyFile(join(pack,'docs/SURGICAL_VIEW_1654623.md'),join(delivery,'使用与开发说明.md'));
await copyFile(join(pack,'content/assets/models/LICENSE-surgerycraft-anatomy.txt'),join(delivery,'代码与模型许可.txt'));
for(const file of ['summary.json','clinical-checks.json','web-complete.png']) {
  await copy(join(pack,'output/pilot-1654623',file),join(delivery,'原病例流程验证',file));
}
const guide=`SurgeryCraft 病例126：三维手术样例 v3\n\n最快查看：\n只需把“${entry}”发给朋友。保存到电脑后，用Chrome或Edge打开，即可离线观看。无需安装Blender、Node或API密钥。需要桌面浏览器支持WebGL。\n\n打开就是腹腔三维术野，含镜像肝胆、胃脾和胆道、血管。拖动旋转，滚轮缩放，点选结构，或切换腹腔镜视角。\n点击“播放演示”：定位→显露→辨认→学习核对→夹闭→离断→胆囊离床→取出。第四步完成两个学习勾选后再次点击播放。也可点击阶段直接查看。\n顶部“医院病例流程”保留先前医院演示；搜索84并选择IMPF外科医院。两个模块在同一HTML中，但评分和学习轨迹尚未互通。\n\n继续开发：\n把本ZIP完整发给朋友并解压。source/content/assets/blender/ 内为Blender 4.5 LTS工程，时间轴1–337帧含八阶段教学关键帧；source/content/assets/models/ 内为GLB和资产清单；source/surgical-view/ 为网页代码，source/tools/blender/ 为可重复建模代码。详细说明见“使用与开发说明.md”。\n\n本样例使用 BodyParts3D/DBCLS 器官表面（CC BY 4.0），经镜像、平滑、材质重制，配合自建胆道及脚本动画，不是患者CT重建、真实组织切割模拟或已通过专家审核的手术训练系统。原文支持脏器侧别，管道口径、精确变异、夹子与操作轨迹是教学设计。100分是先前参考流程的脚本验证，不是LLM研究结果。学习勾选不证明CVS建立。\n本包未附带原始病例PDF、医学图片或BodyVista模型。\n`;
await writeFile(join(delivery,'先读我.txt'),guide,'utf8');
const manifest={schema:'surgerycraft/surgical-demo@3',caseId:'cmcr-1654623',builtAt:new Date().toISOString(),
  entry,htmlBytes:Buffer.byteLength(html),htmlSha256:hash(html),offline:true,
  geometry:'BodyParts3D adapted reference organ surfaces + authored schematic ducts; not patient-derived',clinicalScoreConnected:false,
  clinicianReviewed:false,referenceIncluded:true,sourceMediaIncluded:false,
  model:JSON.parse(await readFile(join(pack,'content/assets/models/cmcr-1654623-anatomy.json'),'utf8'))};
await writeFile(join(delivery,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log('DELIVERY_V3',delivery,(manifest.htmlBytes/1048576).toFixed(2)+' MiB');
