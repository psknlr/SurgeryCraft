import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const pack=fileURLToPath(new URL('../../',import.meta.url));
const delivery=join(pack,'output/delivery-1654623-v3');
const hash=b=>createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(await readFile(join(delivery,'manifest.json'),'utf8'));
const glb=await readFile(join(pack,'content/assets/models/cmcr-1654623-mirror-abdomen.glb'));
assert.equal(glb.toString('ascii',0,4),'glTF');
assert.equal(glb.readUInt32LE(4),2);
assert.equal(glb.readUInt32LE(8),glb.length);
assert.equal(glb.toString('ascii',16,20),'JSON');
const model=JSON.parse(glb.toString('utf8',20,20+glb.readUInt32LE(12)));
assert.equal(hash(glb),manifest.model.sha256);
assert(model.buffers.every(b=>!b.uri),'GLB must be self-contained');
assert.equal(model.meshes.length,48);
const nodes=new Map(model.nodes.map((n,i)=>[n.name,{...n,index:i}]));
for(const name of ['Liver','Gallbladder','GallbladderAssembly','CommonBileDuct','CommonHepaticDuct',
  'CysticDuctRetained','CysticDuctDivision','CysticDuctDistal','CysticArteryRetained','CysticArteryDivision',
  'CysticArteryDistal','HepaticArtery','PortalVein','Clip0','Clip1','Clip2','Clip3',
  'Grasper','ClipApplier','Dissector','SpecimenBag'])assert(nodes.has(name),'Missing '+name);
for(const name of ['Gallbladder','CysticDuctDistal','CysticArteryDistal'])
  assert(nodes.get('GallbladderAssembly').children.includes(nodes.get(name).index),name+' must detach with specimen');
for(const name of ['CommonBileDuct','CommonHepaticDuct','HepaticArtery','PortalVein','CysticDuctRetained'])
  assert(!nodes.get('GallbladderAssembly').children.includes(nodes.get(name).index),name+' must remain outside specimen');
const liverMesh=model.meshes[nodes.get('Liver').mesh];
assert(liverMesh.primitives.some(p=>p.attributes.COLOR_0!==undefined),'Liver tissue colours must export');
assert(!model.animations?.length,'Web state drives this static GLB; avoid double animation');
for(const name of ['GrasperShaft','ClipApplierShaft','DissectorShaft','BagRib0']) {
  const n=nodes.get(name);
  assert(!n.translation||n.translation.every(x=>Math.abs(x)<1e-5),name+' must use the parent local origin');
  assert(!n.rotation||n.rotation.slice(0,3).every(x=>Math.abs(x)<1e-5),name+' must not cancel its parent transform');
}
const html=await readFile(join(delivery,manifest.entry),'utf8');
assert.equal(hash(html),manifest.htmlSha256);
assert.equal(Buffer.byteLength(html),manifest.htmlBytes);
const embedded='data:model/gltf-binary;base64,'+glb.toString('base64');
assert(html.includes(embedded),'Current model must be embedded byte-for-byte');
assert(!/<script\b[^>]*\bsrc=/i.test(html),'No external scripts');
assert(!/<link\b[^>]*\brel="stylesheet"/i.test(html),'No external stylesheet');
const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)];
assert.equal(scripts.length,1,'Embedded hospital must not terminate outer script');
const checkFile=join(pack,'output/surgical-view-build/verification.mjs');
await writeFile(checkFile,scripts[0][1]);
const syntax=spawnSync(process.execPath,['--check',checkFile],{encoding:'utf8',windowsHide:true});
assert.equal(syntax.status,0,syntax.stderr);
const copied=await readFile(join(delivery,'source/content/assets/models/cmcr-1654623-mirror-abdomen.glb'));
assert.equal(hash(copied),hash(glb));
const blend=await readFile(join(delivery,'source/content/assets/blender/cmcr-1654623-mirror-abdomen.blend'));
// Blender 4.5 uncompressed files have the BLENDER header. No program binaries are bundled.
assert.equal(blend.toString('ascii',0,7),'BLENDER');
const report={checkedAt:new Date().toISOString(),passed:true,glbMeshes:model.meshes.length,
  embeddedModelMatches:true,mainDuctAndVesselsOutsideSpecimen:true,liverVertexColours:true,
  externalScripts:0,externalStylesheets:0,javascriptSyntax:'pass',htmlSha256:manifest.htmlSha256,
  note:'Static and state tests supplement actual browser checks; they do not constitute clinical validation.'};
await writeFile(join(delivery,'静态构建验证.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
