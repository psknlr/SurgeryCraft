@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\pilot\run.ps1" -Mode Serve -OpenBrowser
if errorlevel 1 pause
