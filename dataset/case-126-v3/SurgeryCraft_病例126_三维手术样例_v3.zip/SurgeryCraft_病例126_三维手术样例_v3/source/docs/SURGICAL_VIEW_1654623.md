# 病例126：腹腔三维术野样例 v3

打开 `output/delivery-1654623-v3/SurgeryCraft_病例126_三维手术样例.html`，即可进入三维术野。
完整交接包为 `output/SurgeryCraft_病例126_三维手术样例_v3.zip`。
这个入口将精修后的解剖演示与旧医院病例流程放在同一个离线HTML内。

## 看什么、怎样操作

1. 用Chrome或Edge打开HTML；支持WebGL的桌面电脑效果最佳，不需要Blender或API密钥。
2. 拖动旋转、滚轮缩放。左侧搜索并选择结构，勾选控制显隐；右侧可调肝脏透明度、聚焦结构。
3. 点击“腹腔镜视角”查看肝下区域；“常规位置对照”只用于侧别比较，**不是本例解剖**。
4. 点击“播放演示”，观看定位、显露、辨认、安全核对、夹闭、离断、离床、取出八阶段。
5. 第四步暂停：完成两个学习勾选后再次点击播放。勾选不证明临床CVS建立或手术许可。
6. “导出学习轨迹”保存结构选择、阶段、侧别切换和学习检查等JSON事件。
7. 顶部“医院病例流程”进入先前的体素医院。搜索84，选择病例和IMPF外科医院。

新解剖页面直接从“已查阅CT后的教学阶段”开始，含位置与结局信息，不能当盲测输入。
网页双语切换只作用于解剖模块；医院内有自身语言设置。
两个模块目前共享入口和病例身份，**未将解剖操作计入原病例评分**，不冒充完整手术智能体评测。

## 已实现与事实边界

| 内容 | 实现及证据 |
|---|---|
| 腹腔三维术野 | BodyParts3D 器官参考网格，经 Blender 4.5.3 LTS 镜像与表面精修，48个网格、约23.9万多边形；网页使用Three.js加载GLB |
| 12类可选结构 | 肝、胆囊、胆囊管、肝总管、胆总管、胆囊动脉、肝动脉、门静脉、胃、脾、十二指肠、胰腺 |
| 病例位置 | 原文CT记录肝胆在患者左侧、胃脾在右侧、胰头在左；默认从患者前方看，屏幕右方对应患者左侧 |
| 胆道与血管 | 用于空间关系教学的通用走行；尺寸、汇入点、分支、组织形状均不是患者影像分割结果 |
| 夹闭与离断 | 教学图形和预设轨迹；胆囊管、胆囊动脉的中间片段隐藏，远端随胆囊移动，近端和胆总管保留 |
| 胆囊离床与取出 | 预设离床运动与网格袋示意；最后标本离开视野，非柔体切割或器械碰撞模拟 |
| 可编辑工程 | `.blend`含1–337帧八阶段关键帧及摄影机、灯光；按空格播放。关键帧以示意为目的，不含网页学习暂停 |
| 研究轨迹 | 新模块导出独立的visual-learning-trace；原病例评分与轨迹保留原定义 |

这不是患者专属腹腔重建。没有DICOM、真实组织力学、热损伤、出血、胆漏、缝合或麻醉药物模拟。
原文没有给出的精确胆管/动脉变异没有补成患者事实。**模型和动画尚未经外科专家审核**。
现阶段适合向合作者展示设计、检查侧别和讨论任务；不能据此宣称已建立临床可靠仿真或论文级基准。

## 文件与重建

| 文件 | 用途 |
|---|---|
| `content/assets/blender/cmcr-1654623-mirror-abdomen.blend` | 参考器官网格、自建结构、灯光、摄影机与可编辑关键帧 |
| `content/assets/models/cmcr-1654623-mirror-abdomen.glb` | 网页加载的静态几何，动画由网页状态驱动 |
| `content/assets/models/cmcr-1654623-anatomy.json` | 资产来源、坐标、网格数及SHA-256 |
| `tools/blender/build_abdomen_1654623.py` | 用Blender后台重复生成工程与GLB |
| `surgical-view/src/main.js` | 交互、显示与动画；不修改医院引擎 |
| `surgical-view/src/state.mjs` | 阶段播放、跳转和学习暂停状态 |
| `tools/pilot/build-surgical-view.mjs` | 构建单HTML、拷贝开发材料与许可 |
| `tools/pilot/verify-surgical-view.mjs` | 校验GLB结构、嵌入资源与交接文件一致性 |

源码包不包含引擎依赖或Blender程序。开发需Node.js22+，相邻兼容ClinicalCraft目录及其`npm ci`依赖；
可通过`CLINICALCRAFT_DIR`指定引擎位置。命令在SurgeryCraft根目录执行：

```powershell
blender --background --threads 2 --python tools/blender/build_abdomen_1654623.py
node --test surgical-view/src/state.test.mjs
node ../ClinicalCraft/node_modules/vite/bin/vite.js --config surgical-view/vite.config.mjs
node tools/pilot/build-surgical-view.mjs
node tools/pilot/verify-surgical-view.mjs
python tools/pilot/package-surgical-view.py
```

开发页面默认 <http://127.0.0.1:8866/>。首次构建若缺少旧医院离线HTML，会调用原`package.mjs`生成，
该步骤依赖原病例验证产物；完整仓库的旧流程说明见`docs/PILOT_1654623.md`。
交接包内的新HTML已经包含医院代码；从仅有源码包继续构建时，需补齐仓库/运行旧病例流程。
GLB不导出关键帧，避免网页与Blender动画重复叠加；Blender中的关键帧保存在`.blend`。

本机验证包含：8项播放/跳步状态测试、GLB与HTML嵌入一致性、Blender关键帧检查，
以及浏览器内的结构选择、显隐、视角、双语检索、暂停/继续、取出和医院入口操作。
实际画面与学习JSON见交接包`演示验证/`。浏览器实测使用本地HTTP预览同一构建HTML；
文件双击的`file://`方式未在受控浏览器中实测，离线依赖由静态检查核验。

## 参考与许可

- 病例：张少博、余仁斌，《内脏完全反位腹腔镜胆囊切除术一例》，肝胆胰外科杂志2024;36(3):180–181。
  证据索引见`content/cases/cmcr-1654623/evidence.json`，本包未复制原PDF或医学图片。
- 交互参考：[BodyVista说明](https://github.com/FreedomIntelligence/BodyVista/blob/main/README.zh-CN.md)。
  本次参考其结构导航、选择/显隐/聚焦和动态展示思路，没有复制其代码或网格。当前器官表面直接取自 DBCLS 官方 BodyParts3D 数据。
  [BodyVista第三方许可](https://github.com/FreedomIntelligence/BodyVista/blob/main/THIRD_PARTY_NOTICES.md)
  区分程序代码与解剖模型来源，不能将项目MIT直接套用到所有模型。
- 安全暂停依据：[SAGES Safe Cholecystectomy Multi-Society Practice Guideline](https://www.sages.org/publications/guidelines/safe-cholecystectomy-multi-society-practice-guideline/)。
  本模型的透明化、标签与示意三角形**不满足真实CVS建立的证明要求**，也不模拟指南全部条件。
- 原创胆道/器械、网页及生成代码采用MIT；参考器官网格采用CC BY 4.0，见`content/assets/models/LICENSE-surgerycraft-anatomy.txt`。
  医院引擎来源及三方许可随交接包保留。

## 合作时下一步

请外科合作者先审核镜像解剖、胆道/血管关系和动画表达，记录哪些能作为任务、哪些须删改。
随后再设计可观测动作、失败分支、评分和未知状态，将解剖模块事件接入同一受限智能体会话。
在这些完成前，不能用本演示的播放完成率或旧参考脚本100分替代医学LLM评测结果。

## v3 形态与显示修订

肝脏替换为 BodyParts3D 的肝分区表面合并网格，闭合分区接缝后进行平滑与细分；胃、胆囊、十二指肠、胰腺也采用同一参考图谱的表面，保持统一空间变换。所有器官沿X轴镜像，适配本例左右侧别；不声称复现患者尺寸或血管变异。
默认肝脏完全不透明，增加抬肝显露轨迹，并重配更接近组织的色调与光照；透明度仍可手调。胆道、血管、器械和切除过程继续是教学构型。原报告没有提供DICOM，因此不能把提高视觉逼真度等同于患者级重建或临床准确性认证。

来源：BodyParts3D, © The Database Center for Life Science licensed under CC Attribution 4.0 International。
[官方许可](https://dbarchive.biosciencedbc.jp/en/bodyparts3d/lic.html)；[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)。
原始OBJ与来源哈希随开发包保存于 content/assets/source/bodyparts3d/。重新建模需要同目录的 anatomy_surfaces.py。
