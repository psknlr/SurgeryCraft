import { existsSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import type { CaseDefinition } from "../schema/case.js";
import { distinctHistoryHits, EXCLUDE_KEYWORD_FACTOR, interventionNegation, matchExam, matchHistory, matchInterventions, matchOrders, matchSpecificity, normalizeQuery, orderWarnings, parseCase } from "./index.js";
import { longestCommonSubstring, phraseEvidence, phraseScore, prepare, stem, tokenize, tokensMatch } from "./text.js";

const fixture = (name: string): unknown => JSON.parse(readFileSync(new URL(`./__fixtures__/${name}`, import.meta.url), "utf8"));

function load(json: unknown): CaseDefinition {
  const parsed = parseCase(json);
  if (!parsed.ok) throw new Error(JSON.stringify(parsed.issues, null, 2));
  return parsed.value;
}

const V4 = load(fixture("v4-smzl-mini.case.json"));
const SIM = load(fixture("mini-anaphylaxis.case.json"));

/* ------------------------------------------------------------------ */
/* V4 reference implementation — copied verbatim from Virtual Patient  */
/* V4 (custom_cn.js, investigations `is` and matcher `Xd`).            */
/* ------------------------------------------------------------------ */

/* eslint-disable */
var is = [{
  id: "cbc",
  name: "血常规",
  aliases: ["血常规", "血细胞分析", "全血细胞计数", "cbc"],
  type: "text"
}, {
  id: "abdct",
  name: "腹部增强CT",
  aliases: ["腹部增强ct", "全腹增强ct", "腹部ct", "脾脏ct", "胸腹部增强ct", "胸腹增强ct", "增强ct", "ct增强", "ct平扫", "全腹部ct", "全腹ct"],
  type: "image"
}, {
  id: "chestct",
  name: "胸部CT",
  aliases: ["胸部ct", "肺部ct", "肺ct", "胸部增强ct", "肺部增强ct", "胸ct"],
  type: "text"
}, {
  id: "us",
  name: "肝胆脾胰超声",
  aliases: ["超声", "彩超", "b超", "腹部b超", "脾脏超声", "脾脏彩超", "肝胆脾胰", "门静脉超声"],
  type: "image"
}, {
  id: "nodeus",
  name: "浅表淋巴结超声",
  aliases: ["淋巴结超声", "淋巴结彩超", "淋巴结b超"],
  type: "text"
}, {
  id: "pet",
  name: "全身PET/CT",
  aliases: ["petct", "pet/ct", "pet-ct", "pet", "派特"],
  type: "image"
}, {
  id: "marrow",
  name: "骨髓穿刺／细胞学",
  aliases: ["骨髓穿刺", "骨穿", "骨髓细胞学", "骨髓涂片", "骨髓检查"],
  type: "text"
}, {
  id: "biopsy",
  name: "骨髓活检／免疫组化",
  aliases: ["骨髓活检", "骨髓病理", "免疫组化", "ihc"],
  type: "image"
}, {
  id: "flow",
  name: "流式细胞术",
  aliases: ["流式", "免疫分型", "免疫表型", "flow"],
  type: "text"
}, {
  id: "karyo",
  name: "染色体核型分析",
  aliases: ["核型", "染色体", "细胞遗传", "karyotype"],
  type: "image"
}, {
  id: "hbv",
  name: "乙肝筛查／HBV DNA",
  aliases: ["乙肝", "hbv", "肝炎筛查"],
  type: "text"
}, {
  id: "ldh",
  name: "乳酸脱氢酶",
  aliases: ["乳酸脱氢酶", "ldh"],
  type: "text"
}, {
  id: "egfr",
  name: "EGFR基因检测记录",
  aliases: ["egfr", "基因检测", "驱动基因"],
  type: "text"
}];

function Xd(i: string): string[] {
  let e = i.toLowerCase().replace(/\s+/g, "").replace(/（/g, "(").replace(/）/g, ")");
  if (!e) return [];
  let t = is.filter(n => n.aliases.some(s => e.includes(s))).map(n => n.id);
  // @ts-ignore — V4's expression-statement style is preserved verbatim
  return t.includes("pet") && (/腹部|全腹|脾脏|胸腹/.test(e) || (t = t.filter(n => n !== "abdct")), /胸部|肺部/.test(e) || (t = t.filter(n => n !== "chestct"))), t.includes("chestct") && !/腹部|全腹|脾脏|胸腹/.test(e) && (t = t.filter(n => n !== "abdct")), /胸腹/.test(e) && /ct/.test(e) && !t.includes("chestct") && t.push("chestct"), t.includes("nodeus") && (t = t.filter(n => n !== "us")), /心脏|甲状腺|颈动脉|下肢|肾脏|乳腺/.test(e) && /超声|彩超|b超/.test(e) && (t = t.filter(n => n !== "us")), e === "超声" || e === "彩超" || e === "b超" ? ["us", "nodeus"] : e === "ct" || e === "ct检查" || e === "做ct" ? ["abdct", "chestct"] : (/骨髓穿刺/.test(e) && /活检/.test(e) && !t.includes("biopsy") && t.push("biopsy"), t)
}
/* eslint-enable */

const PARITY_QUERIES = [
  "血常规", "CBC", "cbc", "血细胞分析", "全血细胞计数",
  "腹部CT", "腹部增强CT", "胸部CT", "胸腹增强CT", "胸腹部增强CT", "胸腹CT", "胸腹 平扫 CT", "脾脏CT", "全腹CT", "全腹CT平扫", "CT平扫", "增强CT", "肺部增强CT", "肺CT", "胸CT",
  "CT", "ct", " C T ", "CT检查", "做CT", "做 CT", "CT 检查",
  "超声", "彩超", "B超", "b超", " 超 声 ", "腹部B超", "脾脏超声", "脾脏彩超", "门静脉超声", "淋巴结超声", "淋巴结彩超", "淋巴结B超",
  "心脏超声", "甲状腺彩超", "颈动脉B超", "下肢静脉超声", "乳腺彩超", "肾脏超声和淋巴结超声", "心脏彩超+淋巴结超声", "心脏彩超+脾脏超声",
  "PET/CT", "PET-CT", "petct", "PET-CT 腹部", "PET 腹部CT", "PET 胸部CT", "PET 胸部", "petct 肺部 腹部", "PET 胸腹", "派特", "全身PET/CT",
  "骨髓穿刺+活检", "骨髓穿刺 活检", "骨髓穿刺", "骨穿", "骨髓活检", "骨髓病理", "免疫组化", "IHC", "骨髓检查", "骨髓涂片",
  "流式", "流式细胞术", "免疫分型", "Flow", "核型", "染色体核型分析", "Karyotype",
  "乙肝", "HBV DNA", "肝炎筛查", "LDH", "乳酸脱氢酶", "EGFR", "基因检测", "驱动基因",
  "血常规+腹部CT", "血常规，腹部增强CT", "血常规和肝胆脾胰超声", "胸部CT和腹部CT", "（腹部）增强CT", "（胸腹）CT",
  "complete blood count", "abdominal CT", "chest CT scan", "ultrasound", "bone marrow biopsy", "flow cytometry", "PET scan", "hepatitis B",
  "", "   ", "随便看看", "头颅MRI",
];

describe("normalizeQuery", () => {
  it("lower-cases, strips whitespace and maps full-width forms to ASCII", () => {
    expect(normalizeQuery("  血 常 规 ")).toBe("血常规");
    expect(normalizeQuery("（腹部）ＣＴ")).toBe("(腹部)ct");
    expect(normalizeQuery("PET / CT")).toBe("pet/ct");
    expect(normalizeQuery("\u3000CT\t检查\n")).toBe("ct检查");
    expect(normalizeQuery("骨髓穿刺／细胞学")).toBe("骨髓穿刺/细胞学");
  });
});

describe("matchOrders — V4 parity", () => {
  it("uses the V4 investigation aliases verbatim", () => {
    expect(V4.investigations.map((i) => ({ id: i.id, name: i.name, aliases: i.aliases }))).toEqual(is.map(({ id, name, aliases }) => ({ id, name, aliases })));
  });

  it.each(PARITY_QUERIES)("reproduces V4 Xd for %j", (query) => {
    expect(matchOrders(V4, query, "zh-CN")).toEqual(Xd(query));
    expect(matchOrders(V4, query, "en")).toEqual(Xd(query));
  });

  it("covers the interesting V4 branches", () => {
    const outcomes = Object.fromEntries(PARITY_QUERIES.map((q) => [q, Xd(q)]));
    expect(PARITY_QUERIES.length).toBeGreaterThanOrEqual(40);
    expect(outcomes["超声"]).toEqual(["us", "nodeus"]);
    expect(outcomes["做CT"]).toEqual(["abdct", "chestct"]);
    expect(outcomes["胸腹增强CT"]).toEqual(["abdct", "chestct"]);
    expect(outcomes["PET-CT 腹部"]).toEqual(["pet"]);
    expect(outcomes["PET 腹部CT"]).toEqual(["abdct", "pet"]);
    expect(outcomes["PET/CT"]).toEqual(["pet"]);
    expect(outcomes["淋巴结超声"]).toEqual(["nodeus"]);
    expect(outcomes["心脏超声"]).toEqual([]);
    expect(outcomes["骨髓穿刺+活检"]).toEqual(["marrow", "biopsy"]);
    expect(outcomes["胸部CT"]).toEqual(["chestct"]);
    expect(outcomes["complete blood count"]).toEqual([]);
  });

  it("applies exact overrides after rules (equivalent to V4's ordering)", () => {
    // V4 checks exact keys before the biopsy rule; no exact key mentions 骨髓穿刺, so results agree.
    for (const key of Object.keys(V4.orderMatching.exact)) expect(key).not.toMatch(/骨髓穿刺/);
    expect(matchOrders(V4, "ct", "zh-CN")).toEqual(["abdct", "chestct"]);
  });

  it("normalises full-width input beyond V4 (ＣＴ → ct)", () => {
    expect(matchOrders(V4, "腹部ＣＴ", "zh-CN")).toEqual(["abdct"]);
  });
});

describe("matchOrders — generalised", () => {
  it("matches aliases and names across locales", () => {
    expect(matchOrders(SIM, "blood gas", "zh-CN")).toEqual(["abg"]);
    expect(matchOrders(SIM, "查个血气", "en")).toEqual(["abg"]);
    expect(matchOrders(SIM, "Arterial blood gas please", "en")).toEqual(["abg"]);
    expect(matchOrders(SIM, "Chest X-ray", "en")).toEqual(["cxr"]);
    expect(matchOrders(SIM, "头颅CT", "en")).toEqual(["ct-head"]);
    expect(matchOrders(SIM, "tryptase and a CXR", "en")).toEqual(["tryptase", "cxr"]);
    expect(matchOrders(SIM, "MRI spine", "en")).toEqual([]);
  });

  it("drops unknown ids produced by rules and tolerates invalid regexes", () => {
    const json = fixture("mini-anaphylaxis.case.json") as Record<string, unknown>;
    json.orderMatching = { rules: [{ ifMatches: "gas", add: ["ghost", "tryptase"] }, { ifMatches: "(", remove: ["abg"] }], exact: { "全部": ["abg", "ghost"] } };
    const c = load(json);
    expect(matchOrders(c, "blood gas", "en")).toEqual(["abg", "tryptase"]);
    expect(matchOrders(c, "全部", "en")).toEqual(["abg"]);
  });
});

describe("orderWarnings", () => {
  it("returns localized notices whose pattern matches the query", () => {
    expect(orderWarnings(V4, "全腹CT平扫", "abdct", "zh-CN")).toEqual(["原包仅提供腹部增强CT代表图，平扫与增强CT不能视为等价。"]);
    expect(orderWarnings(V4, "全腹CT平扫", "abdct", "en")).toEqual(["Only contrast-enhanced abdominal CT images exist in the source; a non-contrast CT is not equivalent."]);
    expect(orderWarnings(V4, "腹部增强CT", "abdct", "en")).toEqual([]);
    expect(orderWarnings(V4, "胸部CT平扫", "chestct", "zh-CN")).toEqual([]);
  });
});

describe("text scoring primitives", () => {
  it("tokenises English with stop-words and light stemming", () => {
    expect(tokenize("Do you have any allergies?")).toEqual(["allergy"]);
    expect(tokenize("Are you SMOKING these days?")).toEqual(["smok", "day"]);
    expect(tokenize("胸痛 chest pain")).toEqual(["chest", "pain"]);
    expect(tokenize("What's it like? Don't you\u2019re patient's chest")).toEqual(["chest"]);
    expect(stem("breathing")).toBe("breath");
    expect(stem("gas")).toBe("gas");
  });

  it("computes longest common substrings", () => {
    expect(longestCommonSubstring("什么时候开始的", "哪里疼什么时候开始")).toBe(6);
    expect(longestCommonSubstring("", "abc")).toBe(0);
    expect(longestCommonSubstring("abcxyz", "xyzabc")).toBe(3);
  });

  it("scores CJK by LCS ratio and Latin by token coverage", () => {
    expect(phraseScore(prepare("你哪里疼"), prepare("疼"))).toBe(1);
    expect(phraseScore(prepare("什么时候开始的"), prepare("哪里疼，什么时候开始？"))).toBeCloseTo(6 / 9);
    expect(phraseScore(prepare("短"), prepare("哪里疼，什么时候开始？"))).toBe(0);
    expect(phraseScore(prepare("are you breathless"), prepare("short of breath"))).toBe(0.5);
    expect(phraseScore(prepare("pet-ct"), prepare("petct"))).toBe(0.9);
    expect(phraseScore(prepare("doctor"), prepare("ct"))).toBe(0);
  });
});

describe("matchHistory", () => {
  it("matches Chinese utterances (substring/LCS)", () => {
    expect(matchHistory(V4, "以前是否发现过脾大？", "zh-CN")).toEqual([{ id: "spleen", score: 1 }]);
    expect(matchHistory(V4, "你哪里疼", "zh-CN")).toEqual([{ id: "pain", score: 1 }]);
    expect(matchHistory(V4, "什么时候开始的", "zh-CN")).toEqual([{ id: "pain", score: 0.6667 }]);
    expect(matchHistory(V4, "今天天气怎么样", "zh-CN")).toEqual([]);
  });

  it("matches English utterances (tokens, stop-words, stems)", () => {
    expect(matchHistory(SIM, "Are you allergic to anything?", "en")).toEqual([{ id: "allergies", score: 1 }]);
    expect(matchHistory(V4, "Do you smoke?", "en")).toEqual([{ id: "other", score: 1 }]);
    expect(matchHistory(SIM, "what's the weather like", "en")).toEqual([]);
    expect(matchHistory(SIM, "", "en")).toEqual([]);
  });

  it("is cross-lingual", () => {
    expect(matchHistory(SIM, "有没有过敏", "en")).toEqual([{ id: "allergies", score: 1 }]);
    expect(matchHistory(V4, "any lung cancer before?", "zh-CN")).toEqual([{ id: "lung", score: 1 }]);
  });

  it("orders by score, then declaration order", () => {
    expect(matchHistory(V4, "脾大和肿瘤", "zh-CN")).toEqual([
      { id: "spleen", score: 1 },
      { id: "lung", score: 1 },
    ]);
    expect(matchHistory(V4, "什么时候开始发现脾大", "zh-CN")).toEqual([
      { id: "spleen", score: 1 },
      { id: "pain", score: 0.6667 },
    ]);
  });
});

describe("matchExam", () => {
  it("matches maneuvers and keywords in both languages", () => {
    expect(matchExam(SIM, "listen to the chest", "en")).toEqual([{ id: "chest", score: 1 }]);
    expect(matchExam(SIM, "听诊肺部", "zh-CN")).toEqual([{ id: "chest", score: 1 }]);
    expect(matchExam(SIM, "check for hives", "zh-CN")).toEqual([{ id: "skin", score: 1 }]);
    expect(matchExam(V4, "摸一下肚子", "zh-CN")).toEqual([{ id: "abdomen", score: 0.6667 }]);
    expect(matchExam(V4, "Palpate the abdomen", "zh-CN")[0]).toEqual({ id: "abdomen", score: 1 });
  });
});

describe("matchInterventions", () => {
  it("matches names and aliases in both languages", () => {
    expect(matchInterventions(SIM, "give adrenaline now", "en")).toEqual([{ id: "epi", score: 1 }]);
    expect(matchInterventions(SIM, "给予肾上腺素", "zh-CN")).toEqual([{ id: "epi", score: 1 }]);
    expect(matchInterventions(SIM, "epinephrine", "zh-CN")).toEqual([{ id: "epi", score: 1 }]);
    expect(matchInterventions(SIM, "start oxygen", "en")).toEqual([{ id: "oxygen", score: 1 }]);
    expect(matchInterventions(SIM, "吸氧", "en")).toEqual([{ id: "oxygen", score: 1 }]);
    expect(matchInterventions(SIM, "give a beta blocker", "en")).toEqual([{ id: "beta-blocker", score: 1 }]);
    expect(matchInterventions(SIM, "fluid bolus", "en")).toEqual([{ id: "fluids", score: 1 }]);
    expect(matchInterventions(SIM, "something unrelated", "en")).toEqual([]);
  });
});

describe("matchInterventions — negation (docs/GROUNDING.md §2)", () => {
  /** SIM plus an item that itself withholds (stop the beta blocker) and an oral antihistamine. */
  function withWithholding(): CaseDefinition {
    const json = fixture("mini-anaphylaxis.case.json") as { interventions: unknown[] };
    json.interventions.push(
      { id: "stop-bb", name: { en: "Stop the beta blocker", "zh-CN": "停用β受体阻滞剂" }, kind: "medication", aliases: { en: ["hold propranolol"], "zh-CN": ["停普萘洛尔"] } },
      { id: "oral-antihistamine", name: { en: "Oral cetirizine 10 mg", "zh-CN": "口服西替利嗪10mg" }, kind: "medication", aliases: { en: ["oral antihistamine", "cetirizine"], "zh-CN": ["口服抗组胺", "西替利嗪"] } },
    );
    return load(json);
  }
  const c = withWithholding();

  it("never returns the item a negated instruction names (en + zh-CN)", () => {
    for (const q of ["don't give adrenaline", "no adrenaline for now", "hold the epinephrine", "adrenaline not indicated", "不要给肾上腺素", "肾上腺素先不给", "暂停补液"]) {
      expect(matchInterventions(c, q, "en"), q).toEqual([]);
    }
    expect(interventionNegation(c, "don't give adrenaline", "en")).toEqual({ withheld: ["epi"], alternatives: [], scopes: ["give adrenaline"], doubleNegated: [] });
  });

  it("acts on what the instruction still asks for, and on an item that itself withholds", () => {
    expect(matchInterventions(c, "no adrenaline, give oxygen", "en")).toEqual([{ id: "oxygen", score: 1 }]);
    expect(matchInterventions(c, "give oxygen, not a fluid bolus", "en")).toEqual([{ id: "oxygen", score: 1 }]);
    expect(matchInterventions(c, "stop the propranolol", "en")[0]).toEqual({ id: "stop-bb", score: 1 });
    expect(matchInterventions(c, "停用普萘洛尔", "zh-CN")[0]).toEqual({ id: "stop-bb", score: 1 });
    expect(matchInterventions(c, "stop the propranolol", "en").map((h) => h.id)).not.toContain("beta-blocker");
  });

  it("never brings a withheld item back through its class, and keeps an elliptical affirmative item", () => {
    expect(matchInterventions(c, "no IV chlorphenamine, give an oral antihistamine", "en")).toEqual([{ id: "oral-antihistamine", score: 1 }]);
    expect(matchInterventions(c, "no IV chlorphenamine, give an antihistamine", "en").map((h) => h.id)).not.toContain("chlorphenamine");
    // the bolus is withheld; "saline" alone in the affirmative clause still reads as the saline item, at ELLIPSIS_FACTOR at most
    expect(matchInterventions(c, "no adrenaline bolus, just oxygen", "en")).toEqual([{ id: "oxygen", score: 1 }]);
  });

  it("reads a double negative neither way", () => {
    expect(matchInterventions(c, "don't stop the propranolol", "en")).toEqual([]);
    expect(interventionNegation(c, "don't stop the propranolol", "en")).toEqual({ withheld: [], alternatives: [], scopes: [], doubleNegated: ["don't stop the propranolol"] });
  });

  it("resolves an item that withholds what the instruction names, and otherwise offers it", () => {
    expect(matchInterventions(c, "hold the beta blocker", "en")[0]?.id).toBe("stop-bb");
    expect(interventionNegation(c, "hold the beta blocker", "en")?.withheld).toEqual(["beta-blocker"]);
    const json = fixture("mini-anaphylaxis.case.json") as { interventions: unknown[] };
    json.interventions.push({ id: "no-fluids", name: { en: "Withhold fluids (keep dry)", "zh-CN": "暂不补液" }, kind: "fluid", aliases: { en: ["no saline"] } });
    const dry = load(json);
    expect(matchInterventions(dry, "don't run the saline", "en")[0]?.id).toBe("no-fluids");
    expect(matchInterventions(dry, "no bolus", "en")).toEqual([]);
    expect(interventionNegation(dry, "no bolus", "en")).toMatchObject({ withheld: ["fluids"], alternatives: ["no-fluids"] });
    expect(interventionNegation(dry, "no adrenaline", "en")).toMatchObject({ withheld: ["epi"], alternatives: [] });
  });

  it("leaves utterances without negation scored as before", () => {
    expect(matchInterventions(c, "give adrenaline now", "en")).toEqual([{ id: "epi", score: 1 }]);
    expect(interventionNegation(c, "give adrenaline now", "en")).toBeNull();
  });
});

/* ------------------------------------------------------------------ */
/* Stemming regression: "medical" ≠ "medication"                       */
/* ------------------------------------------------------------------ */

/** SIM plus a past-medical-history item next to its medications item (the collision the tighter stemmer fixes). */
function withPmh(): CaseDefinition {
  const json = fixture("mini-anaphylaxis.case.json") as { history: unknown[] };
  json.history.push({
    id: "pmh",
    topic: "pmh",
    question: { en: "Any past medical history?", "zh-CN": "既往有什么病？" },
    answer: { en: "Only mild asthma as a child.", "zh-CN": "小时候有轻度哮喘。" },
    keywords: { en: ["medical history", "medical problems", "illnesses"], "zh-CN": ["既往史", "以前得过什么病"] },
  });
  return load(json);
}

describe("token matching (tightened shared-prefix rule)", () => {
  it("keeps inflections and close derivations together", () => {
    const same = (a: string, b: string) => tokensMatch(tokenize(a)[0], tokenize(b)[0]);
    expect(same("allergy", "allergic")).toBe(true);
    expect(same("breath", "breathless")).toBe(true);
    expect(same("nausea", "nauseous")).toBe(true);
    expect(same("pregnant", "pregnancy")).toBe(true);
    expect(same("diabetes", "diabetic")).toBe(true);
    expect(same("smoking", "smoker")).toBe(true);
    expect(same("palpate", "palpation")).toBe(true);
  });

  it("separates words that merely share a long prefix", () => {
    const same = (a: string, b: string) => tokensMatch(tokenize(a)[0], tokenize(b)[0]);
    expect(same("medical", "medication")).toBe(false);
    expect(same("medical", "medicines")).toBe(false);
    expect(same("history", "historical")).toBe(false);
    expect(same("history", "histology")).toBe(false);
    expect(same("hypertension", "hyperthermia")).toBe(false);
    expect(same("pneumonia", "pneumothorax")).toBe(false);
    expect(same("thrombosis", "thrombolysis")).toBe(false);
    expect(same("aspirin", "aspiration")).toBe(false);
    expect(same("constant", "constipation")).toBe(false);
    // long shared prefixes still separate different procedures/diagnoses
    expect(same("cholecystitis", "cholecystectomy")).toBe(false);
    expect(same("appendicitis", "appendicectomy")).toBe(false);
    expect(same("encephalitis", "encephalopathy")).toBe(false);
    expect(same("laparoscopy", "laparotomy")).toBe(false);
    expect(same("gastroscopy", "gastrostomy")).toBe(false);
  });

  it("a short stem only absorbs inflectional endings (hearing ≁ heart, back ≁ background)", () => {
    const same = (a: string, b: string) => tokensMatch(tokenize(a)[0], tokenize(b)[0]);
    expect(same("hearing", "heart")).toBe(false);
    expect(same("hear", "heartburn")).toBe(false);
    expect(same("hearing", "heartburn")).toBe(false);
    expect(same("back", "background")).toBe(false);
    expect(same("heart", "heartburn")).toBe(false);
    expect(same("pain", "painful")).toBe(true);
    expect(same("pain", "painless")).toBe(true);
    expect(same("itch", "itchy")).toBe(true);
    expect(same("numb", "numbness")).toBe(true);
    expect(same("heart", "hearts")).toBe(true);
    expect(same("rash", "rashes")).toBe(true);
    expect(same("chest", "chesty")).toBe(true);
  });

  it("keeps long clinical derivations together (one more letter of tail after an 8-letter shared prefix)", () => {
    const same = (a: string, b: string) => tokensMatch(tokenize(a)[0], tokenize(b)[0]);
    expect(same("anticoagulants", "anticoagulation")).toBe(true);
    expect(same("prophylaxis", "prophylactic")).toBe(true);
    expect(same("anaphylaxis", "anaphylactic")).toBe(true);
    expect(same("echocardiogram", "echocardiographic")).toBe(true);
    expect(same("haematology", "haematological")).toBe(true);
  });

  it("folds -ological adjectives onto their -ology noun", () => {
    expect(tokenize("pathological oncological serological cytological neurological")).toEqual(tokenize("pathology oncology serology cytology neurology"));
    expect(tokenize("logical")).toEqual(["logical"]);
  });

  it("finds a medication-history item from its derived forms (stroke-case regression)", () => {
    const json = fixture("mini-anaphylaxis.case.json") as { history: unknown[] };
    json.history.push({
      id: "anticoag",
      topic: "medications",
      question: { en: "Do you take blood thinners?", "zh-CN": "吃抗凝药吗？" },
      answer: { en: "No.", "zh-CN": "不吃。" },
      keywords: { en: ["anticoagulant", "warfarin"], "zh-CN": ["抗凝"] },
    });
    const c = load(json);
    for (const q of ["Is he on any anticoagulation?", "Any anticoagulants?", "Is she anticoagulated?"]) {
      expect(matchHistory(c, q, "en")[0], q).toEqual({ id: "anticoag", score: 1 });
    }
  });

  it("folds British spellings and maps a few lemmas", () => {
    expect(tokenize("haemoglobin oedema anaemia")).toEqual(tokenize("hemoglobin edema anemia"));
    expect(tokenize("immunisation nebuliser")).toEqual(tokenize("immunization nebulizer"));
    expect(tokenize("medicines meds medications medicated")).toEqual(["medication", "medication", "medication", "medication"]);
    expect(tokenize("abdominal exam")).toEqual(["abdomen", "exam"]);
    expect(tokenize("medical")).toEqual(["medical"]);
  });

  it('"past medical history" selects the PMH item, never the medications item', () => {
    const c = withPmh();
    for (const q of ["past medical history", "Any medical history?", "medical problems?"]) {
      const ids = matchHistory(c, q, "en").map((h) => h.id);
      expect(ids[0], q).toBe("pmh");
      expect(ids, q).not.toContain("meds");
    }
    // also without a PMH item to fall back on
    expect(matchHistory(SIM, "past medical history", "en").map((h) => h.id)).not.toContain("meds");
  });

  it('"medications" / "medicines" / "drugs" / "meds" still find the medications item', () => {
    const c = withPmh();
    for (const q of ["medications", "medicines", "drugs", "any meds?", "What medicines do you take?", "Are you on any medication?"]) {
      const hits = matchHistory(c, q, "en");
      expect(hits[0], q).toEqual({ id: "meds", score: 1 });
      expect(hits.map((h) => h.id), q).not.toContain("pmh");
    }
  });
});

/* ------------------------------------------------------------------ */
/* excludeKeywords                                                     */
/* ------------------------------------------------------------------ */

describe("excludeKeywords", () => {
  it("defaults to [] on history items, exam findings and interventions", () => {
    expect(SIM.history[0].excludeKeywords).toEqual([]);
    expect(SIM.exam[0].excludeKeywords).toEqual([]);
    expect(SIM.interventions[0].excludeKeywords).toEqual([]);
  });

  it("multiplies the score of a history item by 0.2 when the normalised utterance contains one (any locale)", () => {
    expect(EXCLUDE_KEYWORD_FACTOR).toBe(0.2);
    const json = fixture("mini-anaphylaxis.case.json") as { history: { id: string; excludeKeywords?: unknown }[] };
    json.history.find((h) => h.id === "meds")!.excludeKeywords = { en: ["drug allergy", "allergic to"], "zh-CN": ["药物过敏"] };
    const c = load(json);
    // without the exclusion "drug allergy" hits both items with score 1
    expect(matchHistory(SIM, "Any drug allergy?", "en").map((h) => h.id)).toEqual(["allergies", "meds"]);
    // 1 × 0.2 < MATCH_THRESHOLD: the medications item drops out; other items are untouched
    expect(matchHistory(c, "Any drug allergy?", "en")).toEqual([{ id: "allergies", score: 1 }]);
    expect(matchHistory(c, "Any DRUG-allergy?", "en")).toEqual([{ id: "allergies", score: 1 }]); // case, spacing, punctuation ignored
    expect(matchHistory(c, "Are you allergic to any drugs?", "en").map((h) => h.id)).toEqual(["allergies"]);
    expect(matchHistory(c, "有药物过敏吗", "en").map((h) => h.id)).not.toContain("meds"); // zh keyword applies to an en-locale query
    expect(matchHistory(c, "what drugs do you take", "zh-CN")).toEqual([{ id: "meds", score: 1 }]); // no exclude phrase present
  });

  it("applies to matchExam and matchInterventions with the same semantics", () => {
    const json = fixture("mini-anaphylaxis.case.json") as { exam: { id: string; excludeKeywords?: unknown }[]; interventions: { id: string; excludeKeywords?: unknown }[] };
    json.exam.find((e) => e.id === "chest")!.excludeKeywords = ["chest x-ray", "胸片"];
    json.interventions.find((i) => i.id === "oxygen")!.excludeKeywords = { en: ["oxygen saturation"] };
    const c = load(json);
    expect(matchExam(SIM, "chest x-ray", "en")).toEqual([{ id: "chest", score: 1 }]);
    expect(matchExam(c, "chest x-ray", "en")).toEqual([]);
    expect(matchExam(c, "Chest X ray", "en")).toEqual([]);
    expect(matchExam(c, "胸片", "en")).toEqual([]);
    expect(matchExam(c, "listen to the chest", "en")).toEqual([{ id: "chest", score: 1 }]);
    expect(matchInterventions(SIM, "what is the oxygen saturation", "en")).toEqual([{ id: "oxygen", score: 1 }]);
    expect(matchInterventions(c, "what is the oxygen saturation", "en")).toEqual([]);
    expect(matchInterventions(c, "start oxygen", "en")).toEqual([{ id: "oxygen", score: 1 }]);
  });
});

/* ------------------------------------------------------------------ */
/* match options                                                       */
/* ------------------------------------------------------------------ */

describe("matchHistory / matchExam options", () => {
  function phased(): CaseDefinition {
    const json = fixture("mini-anaphylaxis.case.json") as { history: Record<string, unknown>[]; exam: Record<string, unknown>[] };
    json.history.push({
      id: "meds-later",
      topic: "medications",
      question: { en: "Which medicines were you sent home with?", "zh-CN": "出院带了什么药？" },
      answer: { en: "Two adrenaline pens.", "zh-CN": "两支肾上腺素笔。" },
      keywords: { en: ["discharge medicines"], "zh-CN": ["出院带药"] },
      phases: ["observation"],
    });
    json.history.push({
      id: "unknown-family",
      topic: "family",
      question: { en: "Does anyone in your family have allergies?", "zh-CN": "家里人有过敏的吗？" },
      answer: { en: "I don't know.", "zh-CN": "不清楚。" },
      keywords: { en: ["family allergies"], "zh-CN": ["家族过敏"] },
      disclosure: "unknown",
    });
    (json.history.find((h) => h.id === "meds") as Record<string, unknown>).phases = ["arrival"];
    json.exam.find((e) => e.id === "skin")!.phases = ["observation"];
    return load(json);
  }

  it("keeps the 3-argument form (all phases, unknown items included)", () => {
    const c = phased();
    expect(matchHistory(c, "what medicines", "en").map((h) => h.id)).toEqual(["meds", "meds-later"]);
    expect(matchHistory(c, "family allergies", "en").map((h) => h.id)).toContain("unknown-family");
    expect(matchHistory(c, "what medicines", "en", {})).toEqual(matchHistory(c, "what medicines", "en"));
  });

  it("drops items whose phases exclude options.phase (unrestricted items stay)", () => {
    const c = phased();
    expect(matchHistory(c, "what medicines", "en", { phase: "arrival" }).map((h) => h.id)).toEqual(["meds"]);
    expect(matchHistory(c, "what medicines", "en", { phase: "observation" }).map((h) => h.id)).toEqual(["meds-later"]);
    expect(matchHistory(c, "any allergies?", "en", { phase: "observation" }).map((h) => h.id)).toContain("allergies");
    expect(matchExam(c, "check for hives", "en", { phase: "arrival" })).toEqual([]);
    expect(matchExam(c, "check for hives", "en", { phase: "observation" })).toEqual([{ id: "skin", score: 1 }]);
    expect(matchExam(c, "check for hives", "en")).toEqual([{ id: "skin", score: 1 }]);
  });

  it("includeUnknown: false drops unknown-disclosure history items", () => {
    const c = phased();
    expect(matchHistory(c, "family allergies", "en", { includeUnknown: false }).map((h) => h.id)).not.toContain("unknown-family");
    expect(matchHistory(c, "family allergies", "en", { includeUnknown: true }).map((h) => h.id)).toContain("unknown-family");
    expect(matchExam(c, "listen to the chest", "en", { includeUnknown: false })).toEqual([{ id: "chest", score: 1 }]);
  });
});

describe("short-stem false matches on real cases (hearing ≁ heart)", () => {
  const read = (id: string) => {
    const path = fileURLToPath(new URL(`../../../content/cases/${id}/case.json`, import.meta.url));
    if (!existsSync(path)) return null;
    const parsed = parseCase(JSON.parse(readFileSync(path, "utf8")) as unknown);
    return parsed.ok ? parsed.value : null;
  };
  const stroke = read("acute-ischemic-stroke");
  const appendicitis = read("acute-appendicitis");
  it.skipIf(!stroke || !appendicitis)("a hearing question selects no heart/AF history item", () => {
    expect(matchHistory(stroke!, "Does he have any hearing problems?", "en").map((h) => h.id)).not.toContain("pmh-af");
    // "problems" alone still half-matches "medical problems" — below the 0.55 selection bar, so not answered.
    const pmh = matchHistory(appendicitis!, "Do you have any hearing problems?", "en").find((h) => h.id === "hx-pmh");
    expect(pmh?.score ?? 0).toBeLessThan(0.55);
  });
});

describe("CJK partial overlaps (J1: 2-character runs never select on their own)", () => {
  const score = (u: string, p: string) => phraseScore(prepare(u), prepare(p));
  it("a 2-character run in the middle or end of a 3-character phrase stays below the select band (0.55)", () => {
    expect(score("他今天早上量过血压吗？", "出过血")).toBe(0.5); // 过血
    expect(score("他看东西清楚吗？", "吃东西")).toBe(0.5); // 东西
  });
  it("a run made only of function characters is no overlap at all", () => {
    expect(score("平时每天用什么预防的药？", "担心什么")).toBe(0); // 什么
    expect(score("你平时胰岛素是怎么用的？", "怎么疼")).toBe(0); // 怎么
    expect(score("你平时胰岛素是怎么用的？", "什么药")).toBeLessThan(0.55);
    expect(score("你室友得的什么病？", "吐的什么")).toBe(0); // 的什么
    expect(score("你现在在吃什么药？", "现在在哪")).toBe(0); // 现在在
    expect(score("你喜欢看什么电影？", "来看什么病的")).toBe(0); // 看什么
    expect(score("有没有咳嗽？", "有没有发烧")).toBe(0); // 有没有
    // a run with a topic character still counts, function characters and all
    expect(score("什么时候开始的", "哪里疼，什么时候开始？")).toBeCloseTo(6 / 9, 4);
    expect(score("你以前有什么病？", "家人有什么病")).toBeCloseTo(4 / 6, 4);
  });
  it("reads 痛 and 疼 as one character", () => {
    expect(score("有多痛？", "有多疼")).toBe(1);
    expect(score("头疼吗", "头痛")).toBe(1);
  });
  it("finds a phrase when the learner adds a particle to it, but takes a phrase's own particles literally", () => {
    expect(score("吸过毒吗？", "吸毒")).toBe(0.9);
    expect(score("没吸过毒吧？", "吸毒")).toBe(0.9);
    expect(score("以前住过院吗？", "住院")).toBe(0.9);
    expect(score("平常吃的啥药？", "吃了啥药")).toBeLessThan(0.9); // 了 (just now) is not 的
    expect(score("想不想晕倒？", "晕倒过")).toBeLessThan(0.9); // 过 (has fainted) is not 想晕倒
    expect(score("他怎么了？", "怎么")).toBe(1); // contained, as before
    expect(score("他怎么了啊？", "怎么样")).toBe(0); // no topic character
  });
  it("keeps a shared start (typos) and a phrase spelled out with a few characters between", () => {
    expect(score("她有糖尿并吗？", "糖尿病")).toBeCloseTo(2 / 3, 4);
    expect(score("摸一下肚子", "摸肚子")).toBeCloseTo(2 / 3, 4);
    expect(score("喝水会不会呛", "喝水呛")).toBeCloseTo(2 / 3, 4);
    // containment and longer runs are unchanged
    expect(score("有没有高血压", "高血压")).toBe(1);
    expect(score("血压高不高", "高血压病史")).toBe(0.4);
  });
});

describe("phraseEvidence and distinctHistoryHits (a more specific hit accounts for a lesser one)", () => {
  const ev = (u: string, p: string) => phraseEvidence(prepare(u), prepare(p));
  it("names the utterance's topic characters or tokens a phrase accounts for", () => {
    expect(ev("身边有没有人也拉肚子？", "别人也拉肚子")).toEqual(["c5", "c7", "c8", "c9"]); // 人…拉肚子, not 也
    expect(ev("身边有没有人也拉肚子？", "反复拉肚子")).toEqual(["c7", "c8", "c9"]);
    expect(ev("小便时不疼吧？", "小便疼")).toEqual(["c0", "c1", "c4"]); // spelled out
    expect(ev("以前住过院吗？", "住院")).toEqual(["c2", "c4"]); // but for a particle
    expect(ev("你室友得的什么病？", "吐的什么")).toEqual([]);
    expect(ev("Have you noticed any frothy urine?", "frothy urine")).toEqual(["t1", "t2"]);
    expect(ev("Have you noticed any frothy urine?", "urine")).toEqual(["t2"]);
  });

  const item = (id: string, en: string[], zh: string[]) => ({
    ...SIM.history[0]!,
    id,
    disclosure: "on-ask" as const,
    question: { en: id, "zh-CN": id },
    keywords: { en, "zh-CN": zh },
    excludeKeywords: [],
  });
  const c = {
    ...SIM,
    history: [
      item("urine-volume", ["urine"], ["小便"]),
      item("urine-other", ["frothy urine"], ["小便疼"]),
      item("fever", ["fever"], ["发烧"]),
    ],
  } as CaseDefinition;
  const distinct = (u: string, locale: string) => distinctHistoryHits(c, u, locale, matchHistory(c, u, locale)).map((h) => h.id);

  it("drops a hit whose evidence another hit's evidence properly contains", () => {
    expect(matchHistory(c, "Any frothy urine?", "en").map((h) => h.id)).toEqual(["urine-volume", "urine-other"]);
    expect(distinct("Any frothy urine?", "en")).toEqual(["urine-other"]);
    expect(distinct("小便时不疼吧？", "zh-CN")).toEqual(["urine-other"]);
  });
  it("keeps hits with their own evidence, equal evidence and a lone hit", () => {
    expect(distinct("Any frothy urine or fever?", "en")).toEqual(["urine-other", "fever"]);
    expect(distinct("How much urine do you pass?", "en")).toEqual(["urine-volume", "urine-other"]); // both account for "urine" only
    expect(distinctHistoryHits(c, "urine", "en", [{ id: "urine-volume", score: 1 }, { id: "urine-other", score: 0.5 }])).toEqual([
      { id: "urine-volume", score: 1 },
      { id: "urine-other", score: 0.5 },
    ]);
  });
});

describe("matchSpecificity (tie-break for resolvers)", () => {
  it("prefers the item whose matched phrase covers more of the utterance", () => {
    const c = load({
      ...(fixture("mini-anaphylaxis.case.json") as Record<string, unknown>),
    });
    const ivs = c.interventions;
    expect(ivs.length).toBeGreaterThan(0);
    const fake = {
      ...c,
      interventions: [
        { ...ivs[0]!, id: "transfer", name: { en: "Transfer to the cath lab", "zh-CN": "转导管室" }, aliases: { en: ["go to cath lab"], "zh-CN": [] }, excludeKeywords: [] },
        { ...ivs[0]!, id: "activate", name: { en: "Activate the cath lab", "zh-CN": "启动导管室" }, aliases: { en: ["activate the cath lab"], "zh-CN": [] }, excludeKeywords: [] },
      ],
    } as CaseDefinition;
    const hits = matchInterventions(fake, "activate the cath lab", "en");
    expect(hits.map((h) => h.score)).toEqual([1, 1]);
    expect(matchSpecificity(fake, "interventions", "activate the cath lab", "en", "activate")).toBeGreaterThan(matchSpecificity(fake, "interventions", "activate the cath lab", "en", "transfer"));
    expect(matchSpecificity(fake, "interventions", "activate the cath lab", "en", "nope")).toBe(0);
  });
});
